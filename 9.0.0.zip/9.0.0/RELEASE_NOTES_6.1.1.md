# Telegram Account Manager 6.1.1

## UI correction
- Replaced bot navigation/action inline keyboards with Telegram reply keyboards.
- Account Management now has a real **My Accounts** screen independent of Groups/Channels.
- All six existing account sessions are preserved and loaded from `sessions/`.
- Account selection now works from the Accounts screen, Reaction screen, Individual Operations, and Groups/Channels.
- Account detail actions are available from the reply keyboard: Profile, Edit Profile, Groups, Channels, Join, Leave, Photo, Reconnect, Enable/Disable, Preserve & Disable.
- Restored **Bulk Activity** as a main-menu section.
- Bulk Activity supports Reaction, Poll, Join, Leave, Block, Send PV, and Comment and asks how many active accounts should perform the operation.
- Reaction selection and available/custom reaction selection use reply keyboards.
- Monitor Ignore action uses the reply keyboard; the message link is shown as text.
- Cancel/navigation buttons use reply keyboards.

## Session safety
- Existing `.session` files were not deleted, renamed, or replaced.
- The release contains the same six account session files as 6.1.0.

## Validation
- Python compileall: passed.
- AST parsing: passed.
- All six account Session SQLite integrity checks: `ok`.
- Source UI audit: no `Button.inline` / `Button.url` calls remain in `src/`.

Live Telegram API execution was not performed in the build environment.
