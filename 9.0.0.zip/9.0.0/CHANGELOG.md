
## 8.1.0

- Fixed the Reply Keyboard flow so individual message viewing starts with explicit account selection.
- Replaced Individual Reaction / Send PV buttons with Message Center and Contacts.
- Added Message Center account selection with All Accounts support.
- Added conversation/channel listing, unread-message filtering, and the latest 3 messages per selected dialog.
- Added contact retrieval for one or all active accounts.
- Reworked Bulk Activity to select specific accounts (multi-select) or All Accounts instead of selecting a numeric account count.
- Bulk operations now execute against the exact selected sessions rather than the first N active accounts.
# Changelog

## [Unreleased]

### Added
- Professional keyboard navigation with back buttons
- Improved UI organization and layout
- Enhanced error handling and cleanup

### Improved
- Code organization and structure
- Documentation
- User interface consistency

## [1.0.0] - 2025-01-27

### Initial Release
- Account management system
- Message monitoring with keywords
- Bulk and individual operations
- Statistics and reporting
- Complete test suite
