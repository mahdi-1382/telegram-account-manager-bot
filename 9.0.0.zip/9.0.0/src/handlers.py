import os
import logging
import asyncio
import json
from datetime import datetime
from telethon import TelegramClient, events, Button
from telethon.errors import SessionPasswordNeededError, FloodWaitError
from telethon.tl.types import Channel, Chat
from src.config import API_ID, API_HASH, BOT_TOKEN, CHANNEL_ID, ADMIN_ID ,CLIENTS_JSON_PATH, RATE_LIMIT_SLEEP, GROUPS_BATCH_SIZE, GROUPS_UPDATE_SLEEP
from src.client import SessionManager ,AccountHandler
from src.keyboards import Keyboard
from src.actions import Actions
from src.validation import InputValidator
from src.utils import (
    get_session_name, cleanup_conversation_state, is_session_revoked_error,
    check_admin_access, is_bot_message, prompt_for_input,
    cleanup_handlers_and_state
) 

# Setting up the logger
logger = logging.getLogger(__name__)

REACTION_BUTTONS = frozenset({
    'reaction_thumbsup', 'reaction_heart', 'reaction_fire', 'reaction_party', 'reaction_clap',
    'reaction_laugh', 'reaction_wow', 'reaction_cry', 'reaction_sad', 'reaction_angry', 'reaction_dislike',
    'reaction_check',
})
INDIVIDUAL_ACTIONS = ('reaction', 'send_pv', 'join', 'left', 'block', 'comment')
BULK_ACTIONS = ('reaction', 'poll', 'join', 'leave', 'block', 'comment', 'send_pv')
UNKNOWN_COMMAND = "Command not recognized. Please try again."

CONVERSATION_ROUTES = {
    'phone_number_handler': 'account_handler',
    'code_handler': 'account_handler',
    'password_handler': 'account_handler',
    'profile_edit_handler': 'account_handler',
    'account_membership_handler': 'account_handler',
    'ignore_user_handler': 'keyword_handler',
    'delete_ignore_user_handler': 'keyword_handler',
    'add_keyword_handler': 'keyword_handler',
    'remove_keyword_handler': 'keyword_handler',
    'reaction_link_handler': 'actions',
    'reaction_choice_handler': 'actions',
    'reaction_available_choice_handler': 'actions',
    'poll_link_handler': 'actions',
    'poll_option_handler': 'actions',
    'join_link_handler': 'actions',
    'left_link_handler': 'actions',
    'block_user_handler': 'actions',
    'send_pv_user_handler': 'actions',
    'send_pv_message_handler': 'actions',
    'bulk_send_pv_account_count_handler': 'actions',
    'bulk_send_pv_user_handler': 'actions',
    'bulk_send_pv_message_handler': 'actions',
    'comment_link_handler': 'actions',
    'comment_text_handler': 'actions',
    'bulk_join_link_handler': 'actions',
    'bulk_leave_link_handler': 'actions',
    'bulk_block_user_handler': 'actions',
}


# Constants

def is_callback_event(event):
    """Check if an event is a callback query event"""
    if isinstance(event, events.CallbackQuery.Event):
        return True
    # For testing: callback events have 'data' attribute, message events have 'message' attribute
    # Check if 'data' exists and 'message' is None or doesn't exist
    has_data = hasattr(event, 'data') and getattr(event, 'data', None) is not None
    message_attr = getattr(event, 'message', None)
    # Message is None means it's a callback event, message exists means it's a message event
    has_message = message_attr is not None
    return has_data and not has_message


class CommandHandler:
    def __init__(self, tbot):
        self.bot = tbot

    async def start_command(self, event):
        """
        Handle /start command.
        
        Displays the main menu keyboard to authorized admin users.
        
        Args:
            event: Telegram NewMessage event
        """
        logger.info(f"Start command received from user {event.sender_id}")
        try:
            # Validate ADMIN_ID before comparison
            try:
                from src.utils import validate_admin_id
                validated_admin_id = validate_admin_id(ADMIN_ID)
            except ValueError as e:
                logger.error(f"Invalid ADMIN_ID configuration: {e}")
                await event.respond("Bot configuration error. Please contact administrator.")
                return
            
            if event.sender_id != validated_admin_id:
                logger.warning(f"Unauthorized /start from {event.sender_id}")
                await event.respond("You are not the admin")
                return

            # /start resets any in-progress conversation so the next message is a
            # fresh interaction (other entry points already do this).
            await cleanup_conversation_state(self.bot, event.chat_id)

            buttons = Keyboard.start_keyboard()
            await event.respond(
                "Telegram Management Bot\n\n",
                buttons=buttons
            )

        except Exception as e:
            logger.error(f"Error in start_command: {e}", exc_info=True)
            try:
                await event.respond("Error showing menu. Please try again.")
            except Exception as e2:
                logger.error(f"Error sending error message: {e2}")

class KeywordHandler:
    def __init__(self, tbot):
        self.tbot = tbot

    async def add_keyword_handler(self, event):
        """Add a keyword to monitor"""
        logger.info("add_keyword_handler in KeywordHandler")
        try:
            if is_callback_event(event):
                await prompt_for_input(
                    self.tbot, event,
                    "Please enter the keyword you want to add.",
                    'add_keyword_handler'
                )
                return

            keyword = str(event.message.text.strip())
            
            # Validate keyword
            is_valid, error_msg = InputValidator.validate_keyword(keyword)
            if not is_valid:
                await event.respond(f"{error_msg}")
                return
            
            if keyword not in self.tbot.config['KEYWORDS']:
                self.tbot.config['KEYWORDS'].append(keyword)
                self.tbot.config_manager.save_config(self.tbot.config)
                await event.respond(f"Keyword '{keyword}' added successfully")
            else:
                await event.respond(f"Keyword '{keyword}' already exists")

            keywords = ', '.join(str(k) for k in self.tbot.config['KEYWORDS'])
            await event.respond(f"Current keywords: {keywords}")
            
            # Cleanup conversation state
            await cleanup_conversation_state(self.tbot, event.chat_id)

        except Exception as e:
            logger.error(f"Error adding keyword: {e}")
            await event.respond("Error adding keyword")
            async with self.tbot._conversations_lock:
                self.tbot._conversations.pop(event.chat_id, None)

    async def remove_keyword_handler(self, event):
        """Remove a keyword from monitoring"""
        logger.info("remove_keyword_handler in KeywordHandler")
        try:
            if is_callback_event(event):
                await prompt_for_input(
                    self.tbot, event,
                    "Please enter the keyword you want to remove.",
                    'remove_keyword_handler'
                )
                return

            keyword = str(event.message.text.strip())
            if keyword in self.tbot.config['KEYWORDS']:
                self.tbot.config['KEYWORDS'].remove(keyword)
                self.tbot.config_manager.save_config(self.tbot.config)
                await event.respond(f"Keyword '{keyword}' removed successfully")
            else:
                await event.respond(f"Keyword '{keyword}' not found")

            keywords = ', '.join(str(k) for k in self.tbot.config['KEYWORDS'])
            await event.respond(f"Current keywords: {keywords}")
            
            # Cleanup conversation state
            await cleanup_conversation_state(self.tbot, event.chat_id)

        except Exception as e:
            logger.error(f"Error removing keyword: {e}")
            await event.respond("Error removing keyword")
            await cleanup_conversation_state(self.tbot, event.chat_id)

    async def ignore_user_handler(self, event):
        """Ignore a user from further interaction"""
        logger.info("ignore_user_handler in KeywordHandler")
        try:
            if is_callback_event(event):
                await prompt_for_input(
                    self.tbot, event,
                    "Please enter the user ID you want to ignore.",
                    'ignore_user_handler'
                )
                return

            # Validate and parse user ID
            is_valid, error_msg, user_id = InputValidator.validate_user_id(event.message.text.strip())
            if not is_valid:
                await event.respond(f"{error_msg}")
                return
            
            if user_id not in self.tbot.config['IGNORE_USERS']:
                self.tbot.config['IGNORE_USERS'].append(user_id)
                self.tbot.config_manager.save_config(self.tbot.config)
                await event.respond(f"User ID {user_id} is now ignored")
            else:
                await event.respond(f"User ID {user_id} is already ignored")

            ignored_users = ', '.join(str(u) for u in self.tbot.config['IGNORE_USERS'])
            await event.respond(f"Ignored users: {ignored_users}")
            
            # Cleanup conversation state
            await cleanup_conversation_state(self.tbot, event.chat_id)

        except Exception as e:
            logger.error(f"Error ignoring user: {e}")
            await event.respond("Error ignoring user")
            await cleanup_conversation_state(self.tbot, event.chat_id)

    async def delete_ignore_user_handler(self, event):
        """Remove a user from the ignore list"""
        logger.info("delete_ignore_user_handler in KeywordHandler")
        try:
            if is_callback_event(event):
                await prompt_for_input(
                    self.tbot, event,
                    "Please enter the user ID you want to remove from the ignore list.",
                    'delete_ignore_user_handler'
                )
                return

            # Validate and parse user ID
            is_valid, error_msg, user_id = InputValidator.validate_user_id(event.message.text.strip())
            if not is_valid:
                await event.respond(f"{error_msg}")
                return
            
            if user_id in self.tbot.config['IGNORE_USERS']:
                self.tbot.config['IGNORE_USERS'].remove(user_id)
                self.tbot.config_manager.save_config(self.tbot.config)
                await event.respond(f"User ID {user_id} is no longer ignored")
            else:
                await event.respond(f"User ID {user_id} not found in ignored list")

            ignored_users = ', '.join(str(u) for u in self.tbot.config['IGNORE_USERS'])
            await event.respond(f"Ignored users: {ignored_users}")
            
            # Cleanup conversation state
            await cleanup_conversation_state(self.tbot, event.chat_id)

        except Exception as e:
            logger.error(f"Error deleting ignored user: {e}")
            await event.respond("Error removing user from ignore list")
            await cleanup_conversation_state(self.tbot, event.chat_id)

    async def ignore_user(self, user_id, event): # for channel button
        """Ignore a user from further interaction."""
        logger.info("ignore_user in KeywordHandler")
        try:
            if user_id not in self.tbot.config['IGNORE_USERS']:
                self.tbot.config['IGNORE_USERS'].append(user_id)
                self.tbot.config_manager.save_config(self.tbot.config)
                await event.respond(f"User ID {user_id} is now ignored")
            else:
                await event.respond(f"User ID {user_id} is already ignored")

        except Exception as e:
            logger.error(f"Error ignoring user: {e}")
            await event.respond("Error ignoring user")

class MessageHandler:
    def __init__(self, tbot):
        self.tbot = tbot
        self.account_handler = AccountHandler(tbot)
        self.keyword_handler = KeywordHandler(tbot)
        self.actions = Actions(tbot)
        self.stats_handler = StatsHandler(tbot)

    async def _set_context(self, chat_id, value):
        self.tbot._ui_context[chat_id] = value

    async def _show_main(self, event):
        await cleanup_conversation_state(self.tbot, event.chat_id)
        await event.respond("🤖 <b>Telegram Management Bot</b>\n\nSelect an option:", buttons=Keyboard.start_keyboard())

    async def _show_account_picker(self, event, menu, title, action=None):
        async with self.tbot.active_clients_lock:
            sessions = list(self.tbot.active_clients.keys())
        if not sessions:
            await event.respond("No active accounts available.", buttons=Keyboard.back_button())
            return
        labels = [f"👤 {session}" for session in sessions]
        await self._set_context(event.chat_id, {
            'menu': menu,
            'action': action,
            'accounts': {label: session for label, session in zip(labels, sessions)},
        })
        await event.respond(title, buttons=Keyboard.membership_account_keyboard(labels))

    async def _show_bulk_account_count(self, event, action_name):
        async with self.tbot.active_clients_lock:
            count = len(self.tbot.active_clients)
        if count == 0:
            await event.respond("No active accounts available.", buttons=Keyboard.back_button())
            return
        rows = []
        for n in range(1, count + 1):
            rows.append([f"{n} account{'s' if n != 1 else ''}"])
        rows.append(["All Accounts"])
        rows.append(["🔙 Bulk Activity", "🔙 Main Menu"])
        await self._set_context(event.chat_id, {'menu': 'bulk_count', 'action': action_name, 'max': count})
        await event.respond(f"⚡ <b>Bulk Activity</b>\n\nHow many accounts should perform this operation?\nAvailable: <b>{count}</b>", buttons=Keyboard.reply(rows))

    async def _show_reaction_picker(self, event):
        await self._show_account_picker(event, 'reaction_account_picker', '👍 <b>Reactions</b>\n\nChoose an account:', 'reaction')

    async def _show_membership_picker(self, event):
        await self._show_account_picker(event, 'membership_account_picker', '👥 <b>Groups / Channels</b>\n\nChoose an account:', None)

    async def _show_message_account_picker(self, event, mode='messages'):
        async with self.tbot.active_clients_lock:
            sessions = list(self.tbot.active_clients.keys())
        if not sessions:
            await event.respond("No active accounts available.", buttons=Keyboard.back_button())
            return
        labels = [f"👤 {session}" for session in sessions]
        mapping = {label: session for label, session in zip(labels, sessions)}
        self.tbot._ui_context[event.chat_id] = {
            'menu': 'message_account_picker',
            'mode': mode,
            'accounts': mapping,
        }
        await event.respond(
            "📨 <b>Message Center</b>\n\nSelect an account, or choose All Accounts:",
            buttons=Keyboard.message_account_keyboard(labels),
        )

    async def _show_message_center(self, event, sessions):
        self.tbot._ui_context[event.chat_id] = {
            'menu': 'message_center',
            'selected_sessions': list(sessions),
        }
        names = ', '.join(sessions) if len(sessions) <= 3 else f"{len(sessions)} accounts"
        await event.respond(
            f"📨 <b>Message Center</b>\n\nAccounts: <code>{names}</code>\n\nChoose what you want to view:",
            buttons=Keyboard.message_center_keyboard(),
        )

    async def _show_dialogs_for_sessions(self, event, unread_only=False):
        ctx = getattr(self.tbot, '_ui_context', {}).get(event.chat_id, {}) or {}
        sessions = ctx.get('selected_sessions') or []
        if not sessions:
            await self._show_message_account_picker(event)
            return
        dialog_map = {}
        rows = []
        async with self.tbot.active_clients_lock:
            clients = {s: self.tbot.active_clients.get(s) for s in sessions}
        for session in sessions:
            client = clients.get(session)
            if not client:
                continue
            try:
                async for dialog in client.iter_dialogs(limit=40):
                    unread = int(getattr(dialog, 'unread_count', 0) or 0)
                    if unread_only and unread <= 0:
                        continue
                    title = (dialog.name or 'Unnamed').replace('\n', ' ')[:34]
                    kind = 'Channel' if getattr(dialog, 'is_channel', False) and not getattr(dialog, 'is_group', False) else ('Group' if getattr(dialog, 'is_group', False) else 'Chat')
                    label = f"{session} | {title} [{kind}]"
                    if len(label) > 58:
                        label = label[:55] + '...'
                    if unread:
                        label += f" · {unread} unread"
                    key = f"dialog:{len(dialog_map)}"
                    dialog_map[label] = {'session': session, 'entity': dialog.entity}
                    rows.append(label)
            except Exception as exc:
                logger.warning("Could not load dialogs for %s: %s", session, exc)
        ctx['menu'] = 'dialog_list'
        ctx['dialog_map'] = dialog_map
        self.tbot._ui_context[event.chat_id] = ctx
        heading = "📩 <b>Unread Messages</b>" if unread_only else "📂 <b>Conversations / Channels</b>"
        if not rows:
            await event.respond(f"{heading}\n\nNo matching conversations found.", buttons=Keyboard.dialog_list_keyboard([]))
            return
        await event.respond(f"{heading}\n\nSelect a conversation:", buttons=Keyboard.dialog_list_keyboard(rows[:60]))

    async def _show_recent_messages(self, event, label):
        ctx = getattr(self.tbot, '_ui_context', {}).get(event.chat_id, {}) or {}
        item = (ctx.get('dialog_map') or {}).get(label)
        if not item:
            await event.respond("Conversation not found. Please refresh the list.")
            return
        session, entity = item['session'], item['entity']
        async with self.tbot.active_clients_lock:
            client = self.tbot.active_clients.get(session)
        if not client:
            await event.respond("The selected account is no longer active.", buttons=Keyboard.back_button())
            return
        try:
            messages = await client.get_messages(entity, limit=3)
            lines = [f"📨 <b>{label}</b>", ""]
            if not messages:
                lines.append("No messages found.")
            else:
                for m in reversed(list(messages)):
                    sender = getattr(m, 'sender_id', None)
                    stamp = getattr(m, 'date', None)
                    text_value = (getattr(m, 'raw_text', None) or getattr(m, 'message', None) or '').strip()
                    if not text_value:
                        if getattr(m, 'media', None):
                            text_value = "[Media]"
                        else:
                            text_value = "[Non-text message]"
                    text_value = text_value[:700]
                    lines.append(f"<b>{stamp.strftime('%Y-%m-%d %H:%M') if stamp else ''}</b> · {sender or 'Unknown'}\n{text_value}")
                    lines.append("")
            unread = 0
            # Get the dialog's current unread count without marking it read.
            async for d in client.iter_dialogs(limit=100):
                if getattr(d.entity, 'id', None) == getattr(entity, 'id', None):
                    unread = int(getattr(d, 'unread_count', 0) or 0)
                    break
            if unread:
                lines.append(f"📩 Unread: <b>{unread}</b>")
            ctx['menu'] = 'message_center'
            ctx['current_dialog'] = {'session': session, 'entity': entity, 'label': label}
            self.tbot._ui_context[event.chat_id] = ctx
            await event.respond('\n'.join(lines), buttons=Keyboard.message_center_keyboard())
        except Exception as exc:
            await event.respond(f"Could not read messages.\n\n{str(exc)[:220]}", buttons=Keyboard.message_center_keyboard())

    async def _show_contacts_for_sessions(self, event):
        ctx = getattr(self.tbot, '_ui_context', {}).get(event.chat_id, {}) or {}
        sessions = ctx.get('selected_sessions') or []
        if not sessions:
            await self._show_message_account_picker(event, mode='contacts')
            return
        rows = []
        seen = set()
        async with self.tbot.active_clients_lock:
            clients = {s: self.tbot.active_clients.get(s) for s in sessions}
        for session in sessions:
            client = clients.get(session)
            if not client:
                continue
            try:
                contacts = await client.get_contacts()
                for user in contacts[:80]:
                    name = ' '.join(x for x in [getattr(user, 'first_name', None), getattr(user, 'last_name', None)] if x) or 'Unnamed'
                    username = f"@{user.username}" if getattr(user, 'username', None) else ''
                    phone = getattr(user, 'phone', None) or ''
                    key = (session, user.id)
                    if key in seen:
                        continue
                    seen.add(key)
                    rows.append(f"{session} | {name[:28]} {username} {phone}".strip())
            except Exception as exc:
                logger.warning("Could not load contacts for %s: %s", session, exc)
        ctx['menu'] = 'contacts_list'
        self.tbot._ui_context[event.chat_id] = ctx
        await event.respond(
            "📇 <b>Contacts</b>\n\n" + ('\n'.join(f"• {r}" for r in rows[:45]) if rows else 'No contacts found.'),
            buttons=Keyboard.contacts_list_keyboard([]),
        )

    async def _route_ui_text(self, event, text):
        """Route reply-keyboard navigation. Returns True when consumed."""
        ctx = getattr(self.tbot, '_ui_context', {}).get(event.chat_id, {}) or {}

        # Global navigation buttons must work even when a workflow is active.
        if text in {"🔙 Main Menu", "Back", "Cancel", "❌ Cancel"}:
            await self._show_main(event)
            return True

        # Bulk account selection: toggle individual accounts or select all.
        if ctx.get('menu') == 'bulk_account_picker':
            mapping = ctx.get('accounts', {})
            labels = list(mapping.keys())
            selected = set(ctx.get('selected', set()))
            if text == "☑️ All Accounts":
                selected = set(labels)
            elif text == "🧹 Clear Selection":
                selected.clear()
            elif text == "▶️ Continue":
                if not selected:
                    await event.respond("Select at least one account.", buttons=Keyboard.bulk_account_selection_keyboard(labels, selected))
                    return True
                sessions = [mapping[label] for label in labels if label in selected]
                ctx['bulk_selected_sessions'] = sessions
                action = ctx.get('action')
                ctx['menu'] = 'bulk_running'
                self.tbot._ui_context[event.chat_id] = ctx
                await self.actions.handle_group_action(event, action, len(sessions))
                return True
            elif text in mapping:
                if text in selected:
                    selected.remove(text)
                else:
                    selected.add(text)
            else:
                return False
            ctx['selected'] = selected
            self.tbot._ui_context[event.chat_id] = ctx
            await event.respond("⚡ Select accounts:\n\n" + '\n'.join(("✅ " if l in selected else "⬜ ") + l for l in labels), buttons=Keyboard.bulk_account_selection_keyboard(labels, selected))
            return True

        # Message center account/dialog/contact routing.
        if ctx.get('menu') == 'message_account_picker':
            mapping = ctx.get('accounts', {})
            if text == "🌐 All Accounts":
                await self._show_message_center(event, list(mapping.values()))
                return True
            if text in mapping:
                mode = ctx.get('mode', 'messages')
                await self._show_message_center(event, [mapping[text]])
                if mode == 'contacts':
                    await self._show_contacts_for_sessions(event)
                return True

        if ctx.get('menu') == 'message_center':
            if text == "📂 Conversations":
                await self._show_dialogs_for_sessions(event, unread_only=False); return True
            if text == "📩 Unread Messages":
                await self._show_dialogs_for_sessions(event, unread_only=True); return True
            if text == "📇 Contacts":
                await self._show_contacts_for_sessions(event); return True
            if text == "🔄 Refresh":
                await self._show_dialogs_for_sessions(event, unread_only=False); return True

        if ctx.get('menu') == 'dialog_list':
            if text in (ctx.get('dialog_map') or {}):
                await self._show_recent_messages(event, text); return True
            if text == "📩 Unread Messages":
                await self._show_dialogs_for_sessions(event, unread_only=True); return True
            if text == "🔄 Refresh":
                await self._show_dialogs_for_sessions(event, unread_only=False); return True
            if text == "🔙 Message Accounts":
                await self._show_message_account_picker(event); return True

        if ctx.get('menu') == 'contacts_list':
            if text == "🔄 Refresh Contacts":
                await self._show_contacts_for_sessions(event); return True
            if text == "🔙 Message Accounts":
                await self._show_message_account_picker(event, mode='contacts'); return True

        # Main menu
        if text == "👤 Accounts":
            await cleanup_conversation_state(self.tbot, event.chat_id)
            await event.respond("👤 <b>Account Management</b>\n\nSelect an option:", buttons=Keyboard.account_management_keyboard())
            return True
        if text == "👍 Reactions":
            await cleanup_conversation_state(self.tbot, event.chat_id)
            await self._show_reaction_picker(event)
            return True
        if text == "💬 Messages":
            await cleanup_conversation_state(self.tbot, event.chat_id)
            await self._show_message_account_picker(event)
            return True
        if text == "👥 Groups / Channels":
            await cleanup_conversation_state(self.tbot, event.chat_id)
            await self._show_membership_picker(event)
            return True
        if text == "⚡ Bulk Activity":
            await cleanup_conversation_state(self.tbot, event.chat_id)
            await self._set_context(event.chat_id, {'menu': 'bulk_menu'})
            await event.respond("⚡ <b>Bulk Activity</b>\n\nSelect an operation:", buttons=Keyboard.bulk_keyboard())
            return True
        if text == "📡 Monitor":
            await cleanup_conversation_state(self.tbot, event.chat_id)
            await event.respond("📡 <b>Monitor Mode</b>\n\nSelect an option:", buttons=Keyboard.monitor_keyboard())
            return True
        if text == "📊 Statistics":
            await cleanup_conversation_state(self.tbot, event.chat_id)
            await self.stats_handler.show_stats(event)
            return True
        if text == "ℹ️ Help":
            await cleanup_conversation_state(self.tbot, event.chat_id)
            await event.respond("ℹ️ <b>Management Help</b>\n\n• Existing .session files are loaded automatically.\n• Sessions are never deleted automatically.\n• Account management includes profile, groups/channels, Join/Leave, reconnect and preserve/disable.\n• Bulk Activity runs the same group operations across a selected number of accounts.", buttons=Keyboard.back_button())
            return True

        # Account management
        if text == "📋 My Accounts":
            await self.account_handler.show_accounts(event)
            return True
        if text == "➕ Add Account":
            await self.account_handler.add_account(event)
            return True
        if text == "🔄 Reconnect All":
            if getattr(self.tbot, 'client_manager', None):
                await self.tbot.client_manager.reconnect_all(event)
            else:
                await event.respond("Client manager is not initialized.")
            return True
        if text == "💤 Preserved / Inactive":
            if getattr(self.tbot, 'client_manager', None):
                await self.tbot.client_manager.show_inactive_accounts(event)
            else:
                await event.respond("Client manager is not initialized.")
            return True
        if text == "🔙 Account Management":
            await event.respond("👤 <b>Account Management</b>\n\nSelect an option:", buttons=Keyboard.account_management_keyboard())
            return True
        if text == "🔄 Refresh Accounts" and ctx.get('menu') == 'accounts':
            await self.account_handler.show_accounts(event)
            return True

        # Dynamic account list
        if ctx.get('menu') == 'accounts' and text in ctx.get('accounts', {}):
            session = ctx['accounts'][text]
            await self.account_handler.show_account_detail(event, session)
            return True

        # Account detail
        if ctx.get('menu') == 'account_detail':
            session = ctx.get('session')
            if text == "👤 Profile":
                await self.account_handler.show_profile(event, session)
                return True
            if text == "📝 Edit Profile":
                await self.account_handler.show_edit_profile(event, session)
                return True
            if text == "👥 Groups":
                await self.account_handler.show_memberships(event, session, 'groups')
                return True
            if text == "📢 Channels":
                await self.account_handler.show_memberships(event, session, 'channels')
                return True
            if text == "➕ Join":
                await self.account_handler.join_account_prompt(event, session)
                return True
            if text == "🚪 Leave":
                await self.account_handler.leave_account_prompt(event, session)
                return True
            if text == "🖼 Photo":
                await self.account_handler.send_profile_photo(event, session)
                return True
            if text == "🔄 Reconnect":
                await self.account_handler.reconnect_one(event, session)
                return True
            if text in {"⏸ Disable", "▶️ Enable"}:
                await self.account_handler.toggle_client(session, event)
                return True
            if text == "🗃 Preserve & Disable":
                await self.account_handler.archive_client(session, event)
                return True
            if text == "🔙 Accounts":
                await self.account_handler.show_accounts(event)
                return True
            if text == "🔙 Account":
                await self.account_handler.show_account_detail(event, session)
                return True

        # Edit profile
        if ctx.get('menu') == 'edit_profile':
            session = ctx.get('session')
            if text == "✏️ Change Name":
                await self.account_handler.edit_name_prompt(event, session)
                return True
            if text == "🔗 Change Username":
                await self.account_handler.edit_username_prompt(event, session)
                return True
            if text == "🖼 Change Photo":
                await self.account_handler.edit_photo_prompt(event, session)
                return True
            if text == "🔙 Account":
                await self.account_handler.show_account_detail(event, session)
                return True
            if text == "🔙 Accounts":
                await self.account_handler.show_accounts(event)
                return True

        # Membership account picker
        if ctx.get('menu') == 'membership_account_picker' and text in ctx.get('accounts', {}):
            session = ctx['accounts'][text]
            await self._set_context(event.chat_id, {'menu': 'membership_choice', 'session': session})
            await event.respond(f"👥 <b>Memberships</b>\n\nAccount: <code>{session}</code>\n\nChoose what to view:", buttons=Keyboard.membership_keyboard(session, 'groups'))
            return True
        if ctx.get('menu') == 'membership_choice':
            session = ctx.get('session')
            if text == "👥 Groups":
                await self.account_handler.show_memberships(event, session, 'groups')
                return True
            if text == "📢 Channels":
                await self.account_handler.show_memberships(event, session, 'channels')
                return True
            if text == "🔄 Refresh":
                await self.account_handler.show_memberships(event, session, ctx.get('kind', 'groups'))
                return True
            if text == "🚪 Leave":
                await self.account_handler.leave_account_prompt(event, session)
                return True
            if text == "🔙 Account":
                await self.account_handler.show_account_detail(event, session)
                return True

        # Membership listing
        if ctx.get('menu') == 'membership':
            session = ctx.get('session')
            kind = ctx.get('kind', 'groups')
            if text == "👥 Groups":
                await self.account_handler.show_memberships(event, session, 'groups')
                return True
            if text == "📢 Channels":
                await self.account_handler.show_memberships(event, session, 'channels')
                return True
            if text == "🔄 Refresh":
                await self.account_handler.show_memberships(event, session, kind)
                return True
            if text == "🚪 Leave":
                await self.account_handler.leave_account_prompt(event, session)
                return True
            if text == "🔙 Account":
                await self.account_handler.show_account_detail(event, session)
                return True

        # Reaction account picker
        if ctx.get('menu') == 'reaction_account_picker' and text in ctx.get('accounts', {}):
            session = ctx['accounts'][text]
            async with self.tbot.active_clients_lock:
                account = self.tbot.active_clients.get(session)
            if account:
                await self.actions.reaction(account, event)
            else:
                await event.respond("Account is no longer active.")
            return True

        # Individual account picker
        if ctx.get('menu') == 'individual_account_picker' and text in ctx.get('accounts', {}):
            session = ctx['accounts'][text]
            action = ctx.get('action')
            async with self.tbot.active_clients_lock:
                account = self.tbot.active_clients.get(session)
            if account and action:
                await getattr(self.actions, action)(account, event)
            else:
                await event.respond("Account is no longer active.")
            return True

        # Individual operation menu
        individual = {
            "👍 Reaction": 'reaction', "✉️ Send PV": 'send_pv', "➕ Join": 'join',
            "🚪 Leave": 'left', "🚫 Block": 'block', "💬 Comment": 'comment'
        }
        if ctx.get('menu') == 'individual_menu' and text in individual:
            await self.actions.prompt_individual_action(event, individual[text])
            return True

        # Bulk operation menu
        bulk = {
            "👍 Reaction": 'reaction', "📊 Poll": 'poll', "➕ Join": 'join',
            "🚪 Leave": 'leave', "🚫 Block": 'block', "✉️ Send PV": 'send_pv',
            "💬 Comment": 'comment'
        }
        if ctx.get('menu') == 'bulk_menu' and text in bulk:
            await self._show_bulk_account_count(event, bulk[text])
            return True

        if ctx.get('menu') == 'bulk_count':
            if text == "🔙 Bulk Activity":
                await self._set_context(event.chat_id, {'menu': 'bulk_menu'})
                await event.respond("⚡ <b>Bulk Activity</b>\n\nSelect an operation:", buttons=Keyboard.bulk_keyboard())
                return True
            action = ctx.get('action')
            if text == 'All Accounts':
                n = ctx.get('max', 0)
            else:
                try:
                    n = int(text.split()[0])
                except (ValueError, IndexError):
                    n = 0
            if n > 0:
                await self.actions.handle_group_action(event, action, n)
                return True

        # Monitor notification action
        if ctx.get('menu') == 'monitor_message' and text == "🔇 Ignore":
            sender_id = ctx.get('sender_id')
            if sender_id:
                await self.keyword_handler.ignore_user(sender_id, event)
            else:
                await event.respond("Sender information is unavailable.")
            return True

        # Bulk Activity menu. Every bulk action now starts with account selection.
        bulk = {
            "👍 Reaction": 'reaction',
            "📊 Poll": 'poll',
            "➕ Join": 'join',
            "🚪 Leave": 'leave',
            "🚫 Block": 'block',
            "✉️ Send PV": 'send_pv',
            "💬 Comment": 'comment',
        }
        if text in bulk:
            await self.actions.prompt_group_action(event, bulk[text])
            return True

        # Individual menu: message/reaction/send-PV have been replaced by Message Center.
        if text == "📨 View Messages":
            await self._show_message_account_picker(event)
            return True
        if text == "📇 Contacts":
            await self._show_message_account_picker(event, mode='contacts')
            return True

        # Monitor menu
        monitor = {
            "➕ Add Keyword": self.keyword_handler.add_keyword_handler,
            "➖ Remove Keyword": self.keyword_handler.remove_keyword_handler,
            "🔇 Ignore User": self.keyword_handler.ignore_user_handler,
            "🔊 Remove Ignore": self.keyword_handler.delete_ignore_user_handler,
            "🔄 Update Groups": self.account_handler.update_groups,
            "📁 Show Groups": self.stats_handler.show_groups,
            "🏷 Keywords": self.stats_handler.show_keywords,
            "🚫 Ignored Users": self.stats_handler.show_ignores,
        }
        if text in monitor:
            await monitor[text](event)
            return True

        return False

    async def message_handler(self, event):
        """Handle conversations and reply-keyboard navigation."""
        logger.info(f"message_handler in MessageHandler - message: {event.message.text}")
        if is_bot_message(event, BOT_TOKEN):
            return False
        if event.message.text and event.message.text.startswith('/'):
            return False

        try:
            admin_id = int(ADMIN_ID) if isinstance(ADMIN_ID, str) else ADMIN_ID
            if not await check_admin_access(event, admin_id):
                await event.respond("You are not the admin")
                return False
        except (ValueError, TypeError):
            pass

        text = (event.message.text or '').strip()
        if await self._route_ui_text(event, text):
            return True

        async with self.tbot._conversations_lock:
            handler_name = self.tbot._conversations.get(event.chat_id)
        if handler_name:
            owner_name = CONVERSATION_ROUTES.get(handler_name)
            if owner_name:
                await getattr(getattr(self, owner_name), handler_name)(event)
                return True
        return False

class StatsHandler:
    def __init__(self, tbot):
        self.tbot = tbot

    async def show_stats(self, event):
        """Show bot statistics"""
        logger.info("show_stats in StatsHandler")
        try:
            async with self.tbot.active_clients_lock:
                active_count = len(self.tbot.active_clients)
            
            stats = {
                "Total Accounts": len(self.tbot.config['clients']),
                "Active Accounts": active_count,
                "Keywords": len(self.tbot.config['KEYWORDS']),
                "Ignored Users": len(self.tbot.config['IGNORE_USERS'])
            }

            text = "Bot Statistics\n\n"
            for key, value in stats.items():
                text += f"• {key}: {value}\n"

            await Keyboard.edit_or_respond(event, text, buttons=Keyboard.back_button())

        except Exception as e:
            logger.error(f"Error showing stats: {e}")
            await Keyboard.edit_or_respond(event, "Error showing statistics", buttons=Keyboard.back_button())

    async def show_groups(self, event):
        """Show all groups for all clients"""
        logger.info("show_groups in StatsHandler")
        try:
            clients_data = self.tbot.config.get('clients', {})
            
            if not isinstance(clients_data, dict) or not clients_data:
                await Keyboard.edit_or_respond(event, "No groups found. Please run 'Update Groups' first.", buttons=Keyboard.back_button())
                return
            
            text = "Groups per Account:\n\n"
            total_groups = 0
            
            # Get active clients snapshot to filter revoked sessions
            async with self.tbot.active_clients_lock:
                active_sessions = set(self.tbot.active_clients.keys())
            
            for session, groups in clients_data.items():
                # Skip revoked sessions (in config but not in active_clients and not in inactive_accounts)
                if session not in active_sessions:
                    # Check if it's in inactive_accounts
                    if 'inactive_accounts' not in self.tbot.config or session not in self.tbot.config['inactive_accounts']:
                        # Session is in config but not active and not in inactive_accounts - likely revoked, skip it
                        logger.debug(f"Skipping potentially revoked session {session} in show_groups")
                        continue
                    else:
                        # Check if reason indicates revoked session
                        inactive_reason = self.tbot.config['inactive_accounts'][session].get('reason', '').lower()
                        if 'revoked' in inactive_reason or 'auth' in inactive_reason or 'session' in inactive_reason:
                            logger.debug(f"Skipping revoked session {session} in show_groups")
                            continue
                
                phone = session.replace('.session', '') if session else 'Unknown'
                groups_count = len(groups) if isinstance(groups, list) else 0
                total_groups += groups_count
                text += f"• {phone}: {groups_count} groups\n"
            
            text += f"\nTotal: {total_groups} groups"
            await Keyboard.edit_or_respond(event, text, buttons=Keyboard.back_button())

        except Exception as e:
            logger.error(f"Error showing groups: {e}")
            await Keyboard.edit_or_respond(event, "Error showing groups", buttons=Keyboard.back_button())

    async def show_keywords(self, event):
        """Show all configured keywords"""
        logger.info("show_keywords in StatsHandler")
        try:
            keywords = self.tbot.config.get('KEYWORDS', [])
            
            if not keywords:
                await Keyboard.edit_or_respond(event, "No keywords configured yet.", buttons=Keyboard.back_button())
                return

            text = "Configured Keywords:\n\n"
            for idx, keyword in enumerate(keywords, 1):
                text += f"{idx}. {keyword}\n"

            await Keyboard.edit_or_respond(event, text, buttons=Keyboard.back_button())

        except Exception as e:
            logger.error(f"Error showing keywords: {e}")
            await Keyboard.edit_or_respond(event, "Error showing keywords", buttons=Keyboard.back_button())

    async def show_ignores(self, event):
        """Show all ignored users"""
        logger.info("show_ignores in StatsHandler")
        try:
            ignored_users = self.tbot.config.get('IGNORE_USERS', [])
            
            if not ignored_users:
                await Keyboard.edit_or_respond(event, "No users are currently ignored.", buttons=Keyboard.back_button())
                return

            text = "Ignored Users:\n\n"
            for idx, user_id in enumerate(ignored_users, 1):
                text += f"{idx}. User ID: {user_id}\n"

            await Keyboard.edit_or_respond(event, text, buttons=Keyboard.back_button())

        except Exception as e:
            logger.error(f"Error showing ignored users: {e}")
            await Keyboard.edit_or_respond(event, "Error showing ignored users", buttons=Keyboard.back_button())


class CallbackHandler:
    def __init__(self, tbot):
        self.tbot = tbot
        self.account_handler = AccountHandler(self.tbot)
        self.keyword_handler = KeywordHandler(self.tbot)
        self.stats_handler = StatsHandler(self.tbot)
        self.actions = Actions(self.tbot)

        self.callback_actions = {
            'add_account': self.account_handler.add_account,
            'list_accounts': self.account_handler.show_accounts,
            'check_report_status': self.account_handler.check_all_accounts_report_status,
            'inactive_accounts': self.handle_inactive_accounts,
            'reconnect_all': self.handle_reconnect_all,
            'update_groups': self.account_handler.update_groups,
            'add_keyword': self.keyword_handler.add_keyword_handler,
            'remove_keyword': self.keyword_handler.remove_keyword_handler,
            'ignore_user': self.keyword_handler.ignore_user_handler,
            'remove_ignore_user': self.keyword_handler.delete_ignore_user_handler,
            'show_stats': self.stats_handler.show_stats,
            'show_groups': self.stats_handler.show_groups,
            'show_keyword': self.stats_handler.show_keywords,
            'show_ignores': self.stats_handler.show_ignores,
            'monitor_mode': self.show_monitor_keyboard,
            'account_management': self.show_account_management_keyboard,
            'bulk_operations': self.show_bulk_operations_keyboard,
            'individual_keyboard': self.show_individual_keyboard,
            'report': self.show_report_keyboard,
            'help': self.show_help,
            'reaction': self.show_reaction_menu,
            'memberships': self.show_membership_menu,
            'exit': self.show_start_keyboard,
            'back_to_start': self.handle_back_to_start,
            # Bulk operations
            'bulk_reaction': self.handle_bulk_reaction,
            'bulk_poll': self.handle_bulk_poll,
            'bulk_join': self.handle_bulk_join,
            'bulk_leave': self.handle_bulk_leave,
            'bulk_block': self.handle_bulk_block,
            'bulk_send_pv': self.handle_bulk_send_pv,
            'bulk_comment': self.handle_bulk_comment,
            # Individual operations
            'reaction': self.handle_individual_reaction,
            'send_pv': self.handle_individual_send_pv,
            'join': self.handle_individual_join,
            'left': self.handle_individual_left,
            'block': self.handle_individual_block,
            'comment': self.handle_individual_comment,
        }

    async def show_start_keyboard(self, event):
        """Handles the start keyboard display"""
        # Clean up any active conversations when returning to start
        await cleanup_conversation_state(self.tbot, event.chat_id)
        await Keyboard.show_keyboard('start', event, self.tbot)

    async def handle_back_to_start(self, event):
        """Handle back to start navigation with cleanup"""
        # show_start_keyboard cleans up conversation state and edits the current
        # message in place into the main menu (no stale message left behind).
        await self.show_start_keyboard(event)

    async def show_help(self, event):
        text = (
            "ℹ️ <b>Management Help</b>\n\n"
            "• Existing .session files in <code>sessions/</code> are loaded automatically.\n"
            "• Sessions are never deleted automatically.\n"
            "• Account details show connection, profile and recent dialogs.\n"
            "• Reconnect reloads the existing Session without a new login.\n"
            "• Disable only disconnects the account; the Session file remains intact.\n"
            "• Bulk and individual tools are available from the main menu.\n\n"
            "<b>Navigation:</b> use Back buttons instead of /start while inside an operation."
        )
        await Keyboard.edit_or_respond(event, text, buttons=Keyboard.back_button('back_to_start'))

    async def show_monitor_keyboard(self, event):
        """Handles the monitor mode keyboard display"""
        await Keyboard.show_keyboard('monitor', event, self.tbot)

    async def show_account_management_keyboard(self, event):
        """Handles the account management keyboard display"""
        await Keyboard.show_keyboard('account_management', event, self.tbot)

    async def show_bulk_operations_keyboard(self, event):
        """Handles the bulk operations keyboard display"""
        await Keyboard.show_keyboard('bulk', event, self.tbot)

    async def show_individual_keyboard(self, event):
        """Handles the individual operations keyboard display"""
        await Keyboard.show_keyboard('individual_keyboard', event, self.tbot)

    async def show_report_keyboard(self, event):
        """Handles the report keyboard display"""
        keyboard = Keyboard.report_keyboard()
        try:
            if hasattr(event, 'answer'):
                await event.answer()
            await event.edit("Report Status\n\nPlease select an option:", buttons=keyboard)
        except Exception as e:
            logger.error(f"Error showing report keyboard: {e}")
            await event.respond("Report Status\n\nPlease select an option:", buttons=keyboard)

    async def show_reaction_menu(self, event):
        await self.account_handler.show_accounts(event)

    async def show_membership_menu(self, event):
        async with self.tbot.active_clients_lock:
            sessions = list(self.tbot.active_clients.keys())
        if not sessions:
            await Keyboard.edit_or_respond(event, "No active accounts available.", buttons=Keyboard.back_button())
            return
        labels = [f"👤 {session}" for session in sessions]
        self.tbot._ui_context[event.chat_id] = {'menu': 'membership_account_picker', 'accounts': {label: session for label, session in zip(labels, sessions)}}
        await Keyboard.edit_or_respond(event, "👥 <b>Memberships</b>\n\nChoose an account:", buttons=Keyboard.membership_account_keyboard(labels))

    async def handle_bulk_reaction(self, event):
        """
        Handle bulk reaction operation.
        
        Args:
            event: Telegram CallbackQuery event
        """
        await self.actions.prompt_group_action(event, 'reaction')

    async def handle_bulk_poll(self, event):
        """
        Handle bulk poll operation.
        
        Args:
            event: Telegram CallbackQuery event
        """
        async with self.tbot.active_clients_lock:
            total_accounts = len(self.tbot.active_clients)
        if total_accounts == 0:
            await event.respond("No accounts available for this operation.")
            return
        await self.actions.bulk_poll(event, total_accounts)

    async def handle_bulk_join(self, event):
        """
        Handle bulk join operation.
        
        Args:
            event: Telegram CallbackQuery event
        """
        await self.actions.prompt_group_action(event, 'join')

    async def handle_bulk_leave(self, event):
        """
        Handle bulk leave operation.
        
        Args:
            event: Telegram CallbackQuery event
        """
        await self.actions.prompt_group_action(event, 'leave')

    async def handle_bulk_block(self, event):
        """
        Handle bulk block operation.
        
        Args:
            event: Telegram CallbackQuery event
        """
        await self.actions.prompt_group_action(event, 'block')

    async def handle_bulk_send_pv(self, event):
        """Handle bulk send_pv operation"""
        logger.info("handle_bulk_send_pv in CallbackHandler")

        # Answer the callback query first
        try:
            await event.answer()
            logger.info("Callback query answered")
        except Exception as e:
            logger.warning(f"Failed to answer callback: {e}")

        async with self.tbot.active_clients_lock:
            total_accounts = len(self.tbot.active_clients)
        logger.info(f"Total accounts available: {total_accounts}")
        if total_accounts == 0:
            await event.respond("No accounts available for this operation.")
            return

        # Ask user to specify how many accounts they want to use
        message = f"You currently have {total_accounts} accounts available.\n\nHow many accounts do you want to use for this task?\n\nPlease send a number between 1 and {total_accounts}:"
        logger.info(f"Sending message to user: {message[:50]}...")
        try:
            await event.respond(message)
            logger.info("Message sent successfully")
        except Exception as e:
            logger.error(f"Failed to send message: {e}")
            return

        # Set up conversation to receive the number of accounts
        async with self.tbot._conversations_lock:
            self.tbot._conversations[event.chat_id] = 'bulk_send_pv_account_count_handler'
        logger.info("Conversation state set to bulk_send_pv_account_count_handler")

    async def handle_bulk_comment(self, event):
        """Handle bulk comment operation"""
        logger.info("handle_bulk_comment in CallbackHandler")
        await self.actions.prompt_group_action(event, 'comment')

    # Individual operation handlers
    async def handle_individual_reaction(self, event):
        """Handle individual reaction operation"""
        logger.info("handle_individual_reaction in CallbackHandler")
        await self.actions.prompt_individual_action(event, 'reaction')
    
    async def handle_individual_send_pv(self, event):
        """Handle individual send_pv operation"""
        logger.info("handle_individual_send_pv in CallbackHandler")
        await self.actions.prompt_individual_action(event, 'send_pv')

    async def handle_individual_join(self, event):
        """Handle individual join operation"""
        logger.info("handle_individual_join in CallbackHandler")
        await self.actions.prompt_individual_action(event, 'join')

    async def handle_individual_left(self, event):
        """Handle individual left operation"""
        logger.info("handle_individual_left in CallbackHandler")
        await self.actions.prompt_individual_action(event, 'left')

    async def handle_individual_block(self, event):
        """Handle individual block operation"""
        logger.info("handle_individual_block in CallbackHandler")
        await self.actions.prompt_individual_action(event, 'block')

    async def handle_individual_comment(self, event):
        """Handle individual comment operation"""
        logger.info("handle_individual_comment in CallbackHandler")
        await self.actions.prompt_individual_action(event, 'comment')

    async def handle_reconnect_all(self, event):
        """Reconnect all preserved account sessions."""
        await self._answer_callback(event)
        if getattr(self.tbot, 'client_manager', None):
            await self.tbot.client_manager.reconnect_all(event)
        else:
            await event.respond("Client manager is not initialized.")

    async def handle_inactive_accounts(self, event):
        """
        Handle inactive accounts display.
        
        Args:
            event: Telegram CallbackQuery event
        """
        if hasattr(self.tbot, 'client_manager') and self.tbot.client_manager:
            await self.tbot.client_manager.show_inactive_accounts(event)
        else:
            await event.respond("Client manager not initialized. Please restart the bot.")

    async def _answer_callback(self, event):
        try:
            await event.answer()
        except Exception as e:
            logger.warning(f"Error answering callback query: {e}")

    async def _callback_sender_is_admin(self, event) -> bool:
        try:
            admin_id = int(ADMIN_ID) if isinstance(ADMIN_ID, str) else ADMIN_ID
        except (ValueError, TypeError):
            logger.warning(f"Invalid ADMIN_ID: {ADMIN_ID}, skipping admin check")
            return True
        if admin_id != 0 and event.sender_id != admin_id:
            await event.respond("You are not the admin")
            return False
        return True

    @staticmethod
    def _split_action(data: str):
        """Split callback data into (action, suffix); 'send_pv' contains an underscore."""
        parts = data.split('_')
        if len(parts) >= 3 and parts[0] == 'send' and parts[1] == 'pv':
            return 'send_pv', '_'.join(parts[2:])
        return parts[0], '_'.join(parts[1:])

    async def _handle_ignore(self, event, data):
        parts = data.split('_')
        if len(parts) == 2 and parts[1].isdigit():
            await self.keyword_handler.ignore_user(int(parts[1]), event)
        else:
            logger.error(f"Invalid user ID in callback data: {data}")
            await event.respond("Invalid user ID.")

    async def _handle_toggle(self, event, data):
        await self.account_handler.toggle_client(data.replace('toggle_', ''), event)

    async def _handle_delete(self, event, data):
        """Legacy callback compatibility: disable the account, never delete its Session."""
        session = data.replace('delete_', '', 1)
        await self.account_handler.archive_client(session, event)

    async def _handle_account_or_bulk(self, event, data):
        """Route callbacks like 'reaction_3' (bulk) or 'reaction_98912...' (one account)."""
        action_name, suffix = self._split_action(data)

        # Check the suffix against active accounts first: session keys are phone
        # numbers, so isdigit() alone would read an account pick as a bulk count.
        async with self.tbot.active_clients_lock:
            account = self.tbot.active_clients.get(suffix)
            active_count = len(self.tbot.active_clients)

        if account is not None and action_name in INDIVIDUAL_ACTIONS:
            await getattr(self.actions, action_name)(account, event)
        elif (suffix.isdigit() and action_name in BULK_ACTIONS
              and int(suffix) <= active_count):
            # The count bound stops a vanished digit-only session key from being
            # read as a huge bulk count and fanning out to every account.
            await self.actions.handle_group_action(event, action_name, int(suffix))
        elif action_name in INDIVIDUAL_ACTIONS:
            await event.respond(f"Account {suffix} not found.")
        else:
            await self._fallback(event, data)

    async def _fallback(self, event, data):
        action = self.callback_actions.get(data)
        if action:
            await action(event)
        else:
            logger.warning(f"No handler found for callback data: {data}")
            await event.respond(UNKNOWN_COMMAND)

    async def _route_callback(self, event, data):
        if data == 'cancel':
            await cleanup_conversation_state(self.tbot, event.chat_id)
            # Replace the cancelled prompt in place rather than leaving it behind.
            await self.show_start_keyboard(event)
        elif data == 'request_phone_number':
            await prompt_for_input(
                self.tbot, event,
                "Please enter your phone number:",
                'phone_number_handler'
            )
        elif data in REACTION_BUTTONS:
            await self.actions.reaction_select_handler(event)
        elif data == 'reaction_available':
            await self.actions.show_available_reactions(event)
        elif data.startswith('reaction_custom_'):
            try:
                await self.actions.apply_custom_reaction(event, int(data[len('reaction_custom_'):]))
            except ValueError:
                await event.respond('Invalid custom reaction.')
        elif data in self.callback_actions:
            await self.callback_actions[data](event)
        elif data.startswith('profile_'):
            await self.account_handler.show_profile(event, data[len('profile_'):])
        elif data.startswith('edit_profile_'):
            await self.account_handler.show_edit_profile(event, data[len('edit_profile_'):])
        elif data.startswith('edit_name_'):
            await self.account_handler.edit_name_prompt(event, data[len('edit_name_'):])
        elif data.startswith('edit_username_'):
            await self.account_handler.edit_username_prompt(event, data[len('edit_username_'):])
        elif data.startswith('edit_photo_'):
            await self.account_handler.edit_photo_prompt(event, data[len('edit_photo_'):])
        elif data.startswith('photo_'):
            await self.account_handler.send_profile_photo(event, data[len('photo_'):])
        elif data.startswith('groups_'):
            await self.account_handler.show_memberships(event, data[len('groups_'):], 'groups')
        elif data.startswith('channels_'):
            await self.account_handler.show_memberships(event, data[len('channels_'):], 'channels')
        elif data.startswith('join_account_'):
            await self.account_handler.join_account_prompt(event, data[len('join_account_'):])
        elif data.startswith('leave_account_'):
            await self.account_handler.leave_account_prompt(event, data[len('leave_account_'):])
        elif data.startswith('dialogs_'):
            await self.account_handler.show_dialogs(event, data[len('dialogs_'):])
        elif data.startswith('reconnect_'):
            await self.account_handler.reconnect_one(event, data[len('reconnect_'):])
        elif data.startswith('archive_'):
            await self.account_handler.archive_client(data[len('archive_'):], event)
        elif data.startswith('account_detail_'):
            await self.account_handler.show_account_detail(event, data[len('account_detail_'):])
        elif data.startswith('ignore_'):
            await self._handle_ignore(event, data)
        elif data.startswith('toggle_'):
            await self._handle_toggle(event, data)
        elif data.startswith('delete_'):
            await self._handle_delete(event, data)
        elif '_' in data:
            await self._handle_account_or_bulk(event, data)
        else:
            await self._fallback(event, data)

    async def callback_handler(self, event):
        """Handle callback queries"""
        logger.info("callback_handler in CallbackHandler")
        try:
            if is_bot_message(event, BOT_TOKEN):
                logger.debug(f"Ignoring callback from bot itself")
                return

            await self._answer_callback(event)
            if not await self._callback_sender_is_admin(event):
                return

            await self._route_callback(event, event.data.decode())

        except Exception as e:
            logger.error(f"Error in callback_handler: {e}", exc_info=True)
            try:
                await event.respond("Error processing request. Please try again.")
            except Exception as e2:
                logger.error(f"Error sending error message: {e2}")
