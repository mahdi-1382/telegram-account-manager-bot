import logging
from telethon import Button
from telethon.errors import MessageIdInvalidError

logger = logging.getLogger(__name__)

# Inline-button colour styles (Bot API 9.4 / Telethon 1.43+). Older Telegram
# clients simply render these as normal buttons, so they are safe to always send.
PRIMARY = 'primary'  # blue  — navigation / neutral
SUCCESS = 'success'  # green — create / enable / positive
DANGER = 'danger'    # red   — destructive / cancel

# Header text shown above each named keyboard.
KEYBOARD_MESSAGES = {
    'start': "🤖 Telegram Management Bot\n\nPlease select an option:",
    'monitor': "📡 Monitor Mode\n\nPlease select an option:",
    'bulk': "⚡ Bulk Operations\n\nPlease select an operation:",
    'account_management': "👤 Account Management\n\nPlease select an option:",
    'individual_keyboard': "🎯 Individual Operations\n\nPlease select an operation:",
    'report': "📊 Report Status\n\nPlease select an option:",
}

class Keyboard:
    """Telegram reply-keyboard UI. Inline callbacks remain supported for legacy messages."""

    @staticmethod
    def reply(rows):
        return [[Button.text(str(label), resize=True, single_use=False) for label in row] for row in rows]

    @staticmethod
    async def edit_or_respond(event, text, buttons=None):
        """
        Update the message in place when possible, otherwise send a new one.

        Editing the existing message (instead of sending a new one) keeps the
        chat clean: navigating between menus, prompting for input, and
        cancelling all reuse a single message rather than stacking stale menus.
        """
        if event is None:
            return
        try:
            if hasattr(event, 'answer'):
                await event.answer()
        except Exception as e:
            logger.debug(f"Failed to answer callback: {e}")
        try:
            # Reply keyboards are sent with a new message; Telegram does not allow
            # replacing them through an inline-message edit.
            await event.respond(text, buttons=buttons)
        except Exception as e:
            logger.debug(f"respond failed: {e}")

    @staticmethod
    def start_keyboard():
        return Keyboard.reply([
            ["👤 Accounts", "👍 Reactions"],
            ["💬 Messages", "👥 Groups / Channels"],
            ["⚡ Bulk Activity", "📡 Monitor"],
            ["📊 Statistics", "ℹ️ Help"],
        ])

    @staticmethod
    def monitor_keyboard():
        return Keyboard.reply([
            ["➕ Add Keyword", "➖ Remove Keyword"],
            ["🔇 Ignore User", "🔊 Remove Ignore"],
            ["🔄 Update Groups"],
            ["📁 Show Groups", "🏷 Keywords"],
            ["🚫 Ignored Users"],
            ["🔙 Main Menu"],
        ])

    @staticmethod
    def bulk_keyboard():
        return Keyboard.reply([
            ["👍 Reaction", "📊 Poll"],
            ["➕ Join", "🚪 Leave"],
            ["🚫 Block", "✉️ Send PV"],
            ["💬 Comment"],
            ["🔙 Main Menu"],
        ])

    @staticmethod
    def account_management_keyboard(tbot=None, chat_id=None):
        return Keyboard.reply([
            ["📋 My Accounts"],
            ["➕ Add Account", "🔄 Reconnect All"],
            ["💤 Preserved / Inactive"],
            ["🔙 Main Menu"],
        ])

    @staticmethod
    def account_list_keyboard(labels):
        rows = [[label] for label in labels]
        rows += [["🔄 Refresh Accounts"], ["🔙 Account Management"], ["🔙 Main Menu"]]
        return Keyboard.reply(rows)

    @staticmethod
    def channel_message_keyboard(message_link: str, sender_id: int):
        """Reply keyboard for monitor notifications; URL is shown as plain text."""
        return Keyboard.reply([["🔇 Ignore"]])

    @staticmethod
    def account_detail_keyboard(session: str, active: bool):
        return Keyboard.reply([
            ["👤 Profile", "📝 Edit Profile"],
            ["👥 Groups", "📢 Channels"],
            ["➕ Join", "🚪 Leave"],
            ["🖼 Photo", "🔄 Reconnect"],
            ["⏸ Disable" if active else "▶️ Enable"],
            ["🗃 Preserve & Disable"],
            ["🔙 Accounts", "🔙 Main Menu"],
        ])

    @staticmethod
    def edit_profile_keyboard(session: str):
        return Keyboard.reply([
            ["✏️ Change Name", "🔗 Change Username"],
            ["🖼 Change Photo"],
            ["🔙 Account", "🔙 Accounts"],
        ])

    @staticmethod
    def membership_account_keyboard(labels):
        rows = [[label] for label in labels]
        rows += [["🔙 Main Menu"]]
        return Keyboard.reply(rows)

    @staticmethod
    def membership_keyboard(session: str, kind: str):
        return Keyboard.reply([
            ["👥 Groups", "📢 Channels"],
            ["🔄 Refresh", "🚪 Leave"],
            ["🔙 Account", "🔙 Main Menu"],
        ])

    @staticmethod
    def individual_keyboard():
        return Keyboard.reply([
            ["📨 View Messages", "📇 Contacts"],
            ["➕ Join", "🚪 Leave"],
            ["🚫 Block", "💬 Comment"],
            ["🔙 Main Menu"],
        ])

    @staticmethod
    def bulk_account_selection_keyboard(labels, selected=None):
        selected = set(selected or [])
        rows = []
        for label in labels:
            rows.append([("✅ " if label in selected else "⬜ ") + label])
        rows.append(["☑️ All Accounts", "🧹 Clear Selection"])
        rows.append(["▶️ Continue", "❌ Cancel"])
        return Keyboard.reply(rows)

    @staticmethod
    def message_account_keyboard(labels):
        rows = [[label] for label in labels]
        rows.append(["🌐 All Accounts"])
        rows.append(["🔙 Main Menu"])
        return Keyboard.reply(rows)

    @staticmethod
    def message_center_keyboard():
        return Keyboard.reply([
            ["📂 Conversations", "📩 Unread Messages"],
            ["🔄 Refresh", "📇 Contacts"],
            ["🔙 Main Menu"],
        ])

    @staticmethod
    def dialog_list_keyboard(labels):
        rows = [[label] for label in labels]
        rows += [["📩 Unread Messages", "🔄 Refresh"], ["🔙 Message Accounts", "🔙 Main Menu"]]
        return Keyboard.reply(rows)

    @staticmethod
    def contacts_list_keyboard(labels):
        rows = [[label] for label in labels]
        rows += [["🔄 Refresh Contacts"], ["🔙 Message Accounts", "🔙 Main Menu"]]
        return Keyboard.reply(rows)

    @staticmethod
    def report_keyboard():
        return Keyboard.reply([["📈 Show Stats"], ["🛡 Check Report Status"], ["🔙 Main Menu"]])

    @staticmethod
    def back_button(back_action='back_to_start'):
        label = "🔙 Main Menu"
        if back_action == 'account_management':
            label = "🔙 Account Management"
        elif isinstance(back_action, str) and back_action.startswith('account_detail_'):
            label = "🔙 Account"
        elif back_action == 'list_accounts':
            label = "🔙 Accounts"
        return Keyboard.reply([[label]])

    @staticmethod
    def add_back_button(buttons, back_action='back_to_start'):
        result = [row[:] for row in buttons] if isinstance(buttons, list) else []
        label = "🔙 Main Menu" if back_action == 'back_to_start' else "🔙 Back"
        result.append([Button.text(label, resize=True, single_use=False)])
        return result

    @staticmethod
    def add_cancel_button(buttons):
        """
        Add a cancel button to a keyboard layout.

        Args:
            buttons: List of button rows

        Returns:
            List of button rows with cancel button added
        """
        if not isinstance(buttons, list):
            return buttons

        # Create a copy to avoid modifying the original
        result = [row[:] for row in buttons]

        # Add cancel button as a new row
        result.append([Button.text("❌ Cancel", resize=True, single_use=False)])

        return result

    @staticmethod
    async def show_keyboard(keyboard_name: str, event=None, tbot=None):
        """
        Display a keyboard by name.

        Dynamically selects and displays the appropriate keyboard layout
        based on the keyboard name. Handles both callback queries and
        new messages.

        Args:
            keyboard_name: Name of the keyboard to display
            event: Optional Telegram event (CallbackQuery or NewMessage)
            tbot: Optional TelegramBot instance for dynamic keyboards

        Returns:
            Keyboard layout (list of button rows) or None if not found
        """
        chat_id = event.chat_id if event else None

        keyboards = {
            'start': Keyboard.start_keyboard(),
            'monitor': Keyboard.monitor_keyboard(),
            'bulk': Keyboard.bulk_keyboard(),
            'account_management': Keyboard.account_management_keyboard(tbot, chat_id),
            'channel_message': Keyboard.channel_message_keyboard,
            'toggle_and_delete': Keyboard.toggle_and_delete_keyboard,
            'individual_keyboard': Keyboard.individual_keyboard(),
            'report': Keyboard.report_keyboard()
        }

        # Return the keyboard if it exists
        keyboard = keyboards.get(keyboard_name, None)

        if keyboard is None:
            logger.warning(f"Keyboard {keyboard_name} not found")
            if event:
                await event.respond("Sorry, the requested keyboard is not available.")
            return None

        # Handle function references (channel_message, toggle_and_delete)
        if callable(keyboard):
            logger.warning(f"Keyboard {keyboard_name} is a function reference, not a keyboard layout")
            if event:
                await event.respond("Sorry, this keyboard requires additional parameters.")
            return None

        # Validate keyboard format / non-empty
        if not isinstance(keyboard, list) or len(keyboard) == 0:
            logger.error(f"Invalid or empty keyboard for {keyboard_name}: {type(keyboard)}")
            if event:
                await event.respond("Sorry, the requested keyboard is not available.")
            return None

        if event:
            message_text = KEYBOARD_MESSAGES.get(keyboard_name, "Please select an option:")
            # Reply keyboards cannot be attached through editMessageReplyMarkup;
            # send a fresh menu message so Telegram actually replaces the keyboard.
            try:
                await event.respond(message_text, buttons=keyboard)
            except Exception as e:
                logger.error(f"Could not show reply keyboard {keyboard_name}: {e}")
        
        return keyboard
