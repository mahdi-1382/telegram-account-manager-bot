"""
Utility functions for common operations across the bot.
This module contains reusable functions to reduce code duplication.
"""
from __future__ import annotations

import logging
import asyncio
import random
import os
import re
from typing import Optional, Tuple, Callable, List, Any
from telethon.errors import FloodWaitError, SessionRevokedError
try:
    from telethon.errors.rpcerrorlist import AuthKeyUnregisteredError
except ImportError:
    AuthKeyUnregisteredError = None
from telethon import TelegramClient

logger = logging.getLogger(__name__)


def _revocation_error_types() -> tuple:
    from telethon import errors

    names = (
        'SessionRevokedError', 'SessionExpiredError',
        'AuthKeyUnregisteredError', 'AuthKeyInvalidError',
        'AuthKeyDuplicatedError', 'AuthKeyPermEmptyError',
        'UnauthorizedError', 'UserDeactivatedError', 'UserDeactivatedBanError',
    )
    found = tuple(
        getattr(errors, name) for name in names if isinstance(getattr(errors, name, None), type)
    )
    return found or (SessionRevokedError,)


REVOCATION_ERRORS = _revocation_error_types()

# Full phrases only: "session" or "authorization" alone also match proxy and
# sqlite failures.
REVOCATION_PHRASES = (
    'session revoked',
    'session was revoked',
    'session expired',
    'session has expired',
    'auth key is not registered',
    'authorization key is not registered',
    'key is not registered',
    'auth key unregistered',
    'unregistered auth key',
    'not logged in',
    'user is deactivated',
    'authorization has been invalidated',
)


def sanitize_session_name(session_name: str) -> str:
    """
    Sanitize session name to prevent path traversal attacks.
    
    Args:
        session_name: Raw session name that may contain dangerous characters
        
    Returns:
        Sanitized session name safe for use in file paths
        
    Raises:
        ValueError: If session name is invalid or empty after sanitization
    """
    if not session_name or not isinstance(session_name, str):
        raise ValueError("Session name must be a non-empty string")
    
    # Remove path separators and dangerous characters
    sanitized = re.sub(r'[^\w\-_\.]', '', session_name)
    # Remove any remaining path traversal attempts
    sanitized = sanitized.replace('..', '').replace('/', '').replace('\\', '')
    # Remove leading/trailing dots and dashes
    sanitized = sanitized.strip('.-_')
    
    # Ensure it's not empty
    if not sanitized:
        raise ValueError("Invalid session name: empty after sanitization")
    
    # Limit length to prevent extremely long names
    if len(sanitized) > 255:
        sanitized = sanitized[:255]
        logger.warning(f"Session name truncated to 255 characters")
    
    return sanitized


def get_safe_session_file_path(session_name: str, project_dir: Optional[str] = None) -> str:
    """Return the absolute path of a session file inside the configured sessions directory.

    Session files are deliberately never placed outside ``SESSIONS_DIR``.  This
    function accepts either ``foo`` or ``foo.session`` and normalizes both.
    """
    sanitized = sanitize_session_name(session_name)
    if sanitized.endswith(".session"):
        sanitized = sanitized[:-8]
    if not sanitized:
        raise ValueError("Invalid session name")

    if project_dir is None:
        project_dir = os.path.abspath(os.getenv("SESSIONS_DIR", "sessions"))
    else:
        project_dir = os.path.abspath(project_dir)

    os.makedirs(project_dir, exist_ok=True)
    final_path = os.path.abspath(os.path.join(project_dir, f"{sanitized}.session"))
    common = os.path.commonpath([project_dir, final_path])
    if common != project_dir:
        raise ValueError(f"Path traversal detected: {session_name}")
    return final_path


def session_stem(session_name: str) -> str:
    """Normalize a session filename/key to its stem without directories."""
    name = os.path.basename(str(session_name))
    if name.endswith(".session"):
        name = name[:-8]
    return sanitize_session_name(name)

def get_session_name(account: TelegramClient) -> str:
    """
    Extract session name from a TelegramClient instance.
    
    Args:
        account: TelegramClient instance
        
    Returns:
        Session name or 'Unknown' if extraction fails
    """
    try:
        if hasattr(account, 'session') and hasattr(account.session, 'filename'):
            filename = account.session.filename
            if filename:
                return filename
    except Exception as e:
        logger.debug(f"Failed to read session name: {e}")
    return 'Unknown'


async def cleanup_conversation_state(tbot, chat_id: int):
    """
    Clean up conversation state for a chat.
    
    Args:
        tbot: TelegramBot instance
        chat_id: Chat ID to clean up
    """
    async with tbot._conversations_lock:
        tbot._conversations.pop(chat_id, None)
    # The project uses a single admin chat. Clear transient operation state as
    # well so /start or Cancel can never resume an older workflow. Persistent
    # configuration (clients, sessions, keywords, groups) is untouched.
    transient_prefixes = (
        'temp_', 'profile_edit_', 'account_membership_',
        'reaction_', 'poll_', 'join_', 'left_', 'leave_', 'block_',
        'send_pv_', 'comment_', 'bulk_',
    )
    if hasattr(tbot, '_ui_context'):
        tbot._ui_context.pop(chat_id, None)
    for key in list(getattr(tbot, 'handlers', {}).keys()):
        if key in {'temp_client', 'temp_phone'} or key.startswith(transient_prefixes):
            tbot.handlers.pop(key, None)


def is_session_revoked_error(error: Exception) -> bool:
    """
    Check if an error indicates a revoked session.
    
    Args:
        error: Exception to check
        
    Returns:
        True if error indicates revoked session
    """
    if isinstance(error, REVOCATION_ERRORS):
        return True

    error_msg = str(error).lower()
    return any(phrase in error_msg for phrase in REVOCATION_PHRASES)


def validate_admin_id(admin_id: Any) -> int:
    """
    Validate and convert ADMIN_ID to integer.
    
    Args:
        admin_id: Admin ID value (can be int, str, or None)
        
    Returns:
        Validated admin ID as integer
        
    Raises:
        ValueError: If admin_id is invalid
    """
    if admin_id is None:
        raise ValueError("ADMIN_ID is not set")
    
    try:
        admin_id_int = int(admin_id)
        if admin_id_int <= 0:
            raise ValueError(f"ADMIN_ID must be a positive integer, got: {admin_id_int}")
        return admin_id_int
    except (ValueError, TypeError) as e:
        raise ValueError(f"Invalid ADMIN_ID format: {admin_id}") from e


async def check_admin_access(event, admin_id: int) -> bool:
    """
    Check if event sender is admin.
    
    Args:
        event: Telegram event
        admin_id: Admin user ID
        
    Returns:
        True if sender is admin. When admin_id is 0 (unset) the check fails
        closed in production, and is only bypassed while running under pytest.
    """
    if admin_id == 0:
        # Fail closed unless we're inside a test run, otherwise an unset
        # ADMIN_ID would grant admin access to every user.
        if os.environ.get('PYTEST_CURRENT_TEST'):
            return True
        logger.error("ADMIN_ID is not configured; denying admin access.")
        return False
    try:
        validated_admin_id = validate_admin_id(admin_id)
        return event.sender_id == validated_admin_id
    except ValueError:
        logger.warning(f"Invalid admin_id in check_admin_access: {admin_id}")
        return False


async def execute_bulk_operation(
    accounts: List[TelegramClient],
    operation: Callable,
    operation_name: str,
    semaphore: asyncio.Semaphore,
    counter_lock: asyncio.Lock,
    delay_range: Tuple[float, float] = (2.0, 5.0)
) -> Tuple[int, int, List[str]]:
    """
    Execute a bulk operation across multiple accounts with proper error handling.
    
    Args:
        accounts: List of TelegramClient instances
        operation: Async function to execute for each account
        operation_name: Name of operation for logging
        semaphore: Semaphore for concurrency control
        counter_lock: Lock for thread-safe counter updates
        delay_range: Tuple of (min, max) delay between operations
        
    Returns:
        Tuple of (success_count, error_count, revoked_sessions)
    """
    success_count = 0
    error_count = 0
    revoked_sessions = []
    
    async def execute_with_account(acc):
        nonlocal success_count, error_count, revoked_sessions
        session_name = get_session_name(acc)
        
        async with semaphore:
            try:
                await operation(acc)
                async with counter_lock:
                    success_count += 1
                await asyncio.sleep(random.uniform(*delay_range))
            except FloodWaitError as e:
                async with counter_lock:
                    error_count += 1
                # The operation is counted as failed and not retried, so do NOT
                # sleep here: sleeping would hold a concurrency slot for the full
                # flood-wait window and throttle the rest of the batch for nothing.
                logger.warning(f"FloodWaitError for account {session_name}: {e.seconds}s (skipped, not retried)")
            except (SessionRevokedError, ValueError) as e:
                if is_session_revoked_error(e):
                    async with counter_lock:
                        error_count += 1
                        revoked_sessions.append(session_name)
                    logger.warning(f"Session revoked for account {session_name}: {e}")
                else:
                    async with counter_lock:
                        error_count += 1
                    logger.error(f"Error in {operation_name} with account {session_name}: {e}")
            except Exception as e:
                async with counter_lock:
                    error_count += 1
                logger.error(f"Error in {operation_name} with account {session_name}: {e}")
    
    tasks = [execute_with_account(acc) for acc in accounts]
    await asyncio.gather(*tasks, return_exceptions=True)
    
    return success_count, error_count, revoked_sessions


async def format_bulk_result_message(
    operation_name: str,
    success_count: int,
    error_count: int,
    revoked_sessions: List[str],
    success_emoji: str = "",
    error_emoji: str = ""
) -> str:
    """
    Format a result message for bulk operations.
    
    Args:
        operation_name: Name of the operation
        success_count: Number of successful operations
        error_count: Number of failed operations
        revoked_sessions: List of revoked session names
        success_emoji: Emoji for success message (deprecated, kept for compatibility)
        error_emoji: Emoji for error message (deprecated, kept for compatibility)
        
    Returns:
        Formatted message string
    """
    if error_count == 0:
        return f"{operation_name} completed successfully with {success_count} account(s)."
    else:
        msg = f"{operation_name} completed with {success_count} account(s). {error_count} account(s) encountered errors."
        if revoked_sessions:
            msg += f"\n{len(revoked_sessions)} account(s) were revoked and removed."
        return msg


def get_bot_user_id(bot_token: str) -> Optional[int]:
    """
    Extract bot user ID from bot token.
    
    Args:
        bot_token: Bot token string (format: "bot_id:bot_secret")
        
    Returns:
        Bot user ID or None if extraction fails
    """
    try:
        return int(bot_token.split(':')[0])
    except (ValueError, AttributeError, IndexError):
        return None


def is_bot_message(event, bot_token: str) -> bool:
    """
    Check if event is from the bot itself.
    
    Args:
        event: Telegram event
        bot_token: Bot token string
        
    Returns:
        True if message is from bot itself
    """
    bot_user_id = get_bot_user_id(bot_token)
    if bot_user_id is None:
        return False
    return event.sender_id == bot_user_id


async def cleanup_handlers_and_state(
    tbot,
    handler_keys: List[str],
    chat_id: Optional[int] = None
):
    """
    Clean up handler keys and conversation state.
    
    This is the main function for cleaning up handlers and conversation state.
    The duplicate `cleanup_handlers` function has been removed.
    
    Args:
        tbot: TelegramBot instance
        handler_keys: List of keys to remove from handlers
        chat_id: Optional chat_id to also clean conversation state
    """
    for key in handler_keys:
        tbot.handlers.pop(key, None)
    
    if chat_id is not None:
        await cleanup_conversation_state(tbot, chat_id)


async def resolve_entity(peer, account):
    """
    Resolve entity from peer (can be str, int, or already resolved entity).
    
    Args:
        peer: Entity identifier (str username, int ID, or entity object)
        account: TelegramClient instance
        
    Returns:
        Resolved entity
        
    Raises:
        Exception: If entity cannot be resolved (e.g., revoked session)
    """
    # Check if peer is None
    if peer is None:
        raise ValueError("Cannot resolve None entity")
    
    if isinstance(peer, str):
        if not peer.strip():
            raise ValueError("Cannot resolve empty string entity")
        try:
            return await account.get_entity(peer)
        except Exception as e:
            # Check if it's a revoked session error
            if is_session_revoked_error(e) or (AuthKeyUnregisteredError and isinstance(e, AuthKeyUnregisteredError)):
                logger.error(f"Session revoked or unregistered while resolving entity: {e}")
                raise SessionRevokedError("Session revoked or unregistered")
            raise
    elif isinstance(peer, int) and peer < 0:
        try:
            return await account.get_entity(peer)
        except Exception as e:
            # Check if it's a revoked session error
            if is_session_revoked_error(e) or (AuthKeyUnregisteredError and isinstance(e, AuthKeyUnregisteredError)):
                logger.error(f"Session revoked or unregistered while resolving entity: {e}")
                raise SessionRevokedError("Session revoked or unregistered")
            raise
    # Return peer as-is if it's already a resolved entity or positive int
    return peer


async def send_error_message(tbot, chat_id: int, error: Exception, error_type: str = "general"):
    """
    Send appropriate error message based on error type.
    
    Args:
        tbot: TelegramBot instance
        chat_id: Chat ID to send message to
        error: Exception that occurred
        error_type: Type of error ('code', 'password', 'phone', 'general')
    """
    error_str = str(error).lower()
    
    error_messages = {
        'code': {
            'phone code invalid': "Invalid verification code.\n\nPlease start over with /start and try again.",
            'code invalid': "Invalid verification code.\n\nPlease start over with /start and try again.",
            'phone code expired': "Verification code has expired.\n\nPlease start over with /start and enter the code faster.",
            'code expired': "Verification code has expired.\n\nPlease start over with /start and enter the code faster.",
            'timeout': "Connection timeout.\n\nPlease check your internet and try again.",
            'default': f"Error verifying code: {str(error)[:100]}\n\nPlease start over with /start."
        },
        'password': {
            'password': "Invalid password.\n\nPlease start over with /start and try again with the correct password.",
            'timeout': "Connection timeout.\n\nPlease check your internet and try again.",
            'default': f"Error verifying password: {str(error)[:100]}\n\nPlease start over with /start."
        },
        'phone': {
            'flood': "Too many requests. Please wait a few minutes and try again.",
            'phone': "Invalid phone number. Please check the format and try again.",
            'network': "Network error. Please check your connection and try again.",
            'connection': "Network error. Please check your connection and try again.",
            'api': "API credentials error. Please contact the administrator.",
            'default': f"Failed to add account: {str(error)[:100]}..."
        },
        'general': {
            'default': f"Error: {str(error)[:100]}"
        }
    }
    
    messages = error_messages.get(error_type, error_messages['general'])
    
    # Find matching error message
    message = messages.get('default', "An error occurred. Please try again.")
    for key, msg in messages.items():
        if key != 'default' and key in error_str:
            message = msg
            break
    
    await tbot.tbot.send_message(chat_id, message)


def extract_account_name(client) -> str:
    """
    Extract account name from TelegramClient instance.
    
    Args:
        client: TelegramClient instance
        
    Returns:
        Account name or 'Unknown Account'
    """
    try:
        if hasattr(client, 'session') and hasattr(client.session, 'filename'):
            filename = client.session.filename
            if filename:
                account_name = str(filename)
                # Remove .session extension if present
                if account_name.endswith('.session'):
                    account_name = account_name[:-8]
                return account_name
    except Exception as e:
        logger.debug(f"Failed to read session name: {e}")
    return 'Unknown Account'


async def prompt_for_input(
    tbot,
    event,
    prompt_message: str,
    conversation_state: str,
    cancel_button: bool = True
):
    """
    Prompt user for input and set conversation state.
    
    Args:
        tbot: TelegramBot instance
        event: Telegram event
        prompt_message: Message to prompt user
        conversation_state: State name to set in conversations
        cancel_button: Whether to show cancel button
    """
    from src.keyboards import Keyboard
    buttons = Keyboard.reply([["❌ Cancel"]]) if cancel_button else None
    # Edit the menu in place into the prompt (falls back to a new message when the
    # event isn't an editable bot message) so prompts replace the menu instead of
    # stacking new messages on top of the old keyboard.
    await Keyboard.edit_or_respond(event, prompt_message, buttons=buttons)
    async with tbot._conversations_lock:
        tbot._conversations[event.chat_id] = conversation_state


async def validate_and_respond(
    event,
    validation_func,
    input_value: str,
    error_prefix: str = ""
) -> tuple[bool, any]:
    """
    Validate input and respond with error if invalid.
    
    Args:
        event: Telegram event
        validation_func: Validation function that returns (is_valid, error_msg, ...)
        input_value: Input value to validate
        error_prefix: Prefix for error messages
        
    Returns:
        Tuple of (is_valid, validated_value or None)
    """
    result = validation_func(input_value)
    is_valid = result[0]
    
    if not is_valid:
        error_msg = result[1] if len(result) > 1 else "Invalid input"
        await event.respond(f"{error_prefix} {error_msg}")
        return False, None
    
    # Return validated value if available
    validated_value = result[2] if len(result) > 2 else input_value
    return True, validated_value


async def check_account_exists(
    tbot,
    event,
    account_key: str = 'account',
    error_message: str = "Account not found. Please start over."
) -> tuple[bool, any]:
    """
    Check if account exists in handlers and respond with error if not.
    
    Args:
        tbot: TelegramBot instance
        event: Telegram event
        account_key: Key in handlers to check
        error_message: Error message to send if account not found
        
    Returns:
        Tuple of (exists, account or None)
    """
    account = tbot.handlers.get(account_key)
    if not account:
        await event.respond(error_message)
        await cleanup_conversation_state(tbot, event.chat_id)
        return False, None
    return True, account


async def remove_revoked_session_completely(tbot, session_name: str):
    """Deactivate a revoked session without deleting its Session file.

    The historical project deleted revoked Session files automatically. This
    version deliberately preserves them so an administrator can inspect,
    back up, or re-enable the account later.
    """
    base_name = session_stem(session_name)
    client_to_disconnect = None
    async with tbot.active_clients_lock:
        resolved_key = base_name if base_name in tbot.active_clients else None
        if resolved_key is None:
            for key, client in list(tbot.active_clients.items()):
                if session_stem(get_session_name(client)) == base_name:
                    resolved_key = key
                    break
        if resolved_key is not None:
            client_to_disconnect = tbot.active_clients.pop(resolved_key)

    if client_to_disconnect is not None:
        if hasattr(tbot, 'monitor'):
            tbot.monitor.cleanup_client_handlers(client_to_disconnect)
        try:
            await client_to_disconnect.disconnect()
        except Exception:
            logger.debug("Error disconnecting %s", base_name, exc_info=True)

    tbot.config.setdefault('inactive_accounts', {})[base_name] = {
        'phone': base_name,
        'last_seen': __import__('time').time(),
        'reason': 'session_revoked_or_unavailable',
        'error_details': 'Session preserved; Telegram reported an authorization/session problem.'
    }
    if 'clients' not in tbot.config:
        tbot.config['clients'] = {}
    tbot.config['clients'].setdefault(base_name, [])
    tbot.config_manager.save_config(tbot.config)
    logger.warning("Session %s marked inactive; file preserved.", base_name)

async def check_accounts_available(
    tbot,
    event,
    accounts: list,
    error_message: str = "No active accounts found."
) -> bool:
    """
    Check if accounts list is not empty and respond with error if empty.
    
    Args:
        tbot: TelegramBot instance
        event: Telegram event
        accounts: List of accounts to check
        error_message: Error message to send if no accounts
        
    Returns:
        True if accounts available, False otherwise
    """
    if not accounts:
        from src.keyboards import Keyboard
        await Keyboard.edit_or_respond(event, error_message, buttons=Keyboard.back_button())
        await cleanup_conversation_state(tbot, event.chat_id)
        return False
    return True

