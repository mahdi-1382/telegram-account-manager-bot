import os
import time
import logging
import asyncio
import json
from io import BytesIO
from datetime import datetime
from telethon import TelegramClient, events, Button
from telethon.errors import SessionPasswordNeededError, FloodWaitError
from telethon.tl.types import Channel, Chat
from telethon.tl.functions.channels import JoinChannelRequest, LeaveChannelRequest, GetFullChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest, DeleteChatUserRequest
from telethon.tl.functions.account import UpdateProfileRequest, UpdateUsernameRequest
from telethon.tl.functions.photos import UploadProfilePhotoRequest
from src.config import ConfigManager, API_ID, API_HASH, ADMIN_ID, CHANNEL_ID, CLIENTS_JSON_PATH, RATE_LIMIT_SLEEP, GROUPS_BATCH_SIZE, GROUPS_UPDATE_SLEEP, REPORT_CHECK_BOT, SESSIONS_DIR
from src.keyboards import Keyboard
from src.validation import InputValidator
from src.utils import send_error_message, extract_account_name, prompt_for_input, is_session_revoked_error, remove_revoked_session_completely, sanitize_session_name, get_safe_session_file_path, session_stem


# Set up logger for the SessionManager class
logger = logging.getLogger(__name__)

class SessionManager:
    def __init__(self, config, active_clients, tbot):
        """
        Initialize the SessionManager to handle Telegram client sessions.
        :param config: Configuration dictionary for client sessions.
        :param active_clients: Dictionary of active clients mapped by session names.
        :param tbot: Telegram bot instance for sending messages.
        """
        try:
            self.config = config
            self.active_clients = active_clients
            self.tbot = tbot
            # Use ConfigManager to manage client configurations
            self.config_manager = ConfigManager("clients.json", self.config)
            logger.info("SessionManager initialized successfully.")
        except Exception as e:
            logger.critical(f"Error initializing SessionManager: {e}")
            raise

    async def detect_sessions(self):
        """Discover existing Session files and prepare TelegramClient objects.

        Existing .session files are authoritative. They are never deleted or
        overwritten merely because they are temporarily offline.
        """
        try:
            os.makedirs(SESSIONS_DIR, exist_ok=True)
            if not isinstance(self.config.get('clients'), dict):
                self.config['clients'] = {}

            discovered = {}
            for filename in os.listdir(SESSIONS_DIR):
                if filename.endswith('.session'):
                    try:
                        stem = session_stem(filename)
                        discovered[stem] = self.config['clients'].get(stem, [])
                    except ValueError:
                        logger.warning("Skipping invalid session filename: %s", filename)

            for key, value in self.config['clients'].items():
                try:
                    discovered.setdefault(session_stem(key), value)
                except ValueError:
                    logger.warning("Skipping invalid configured session: %s", key)

            if discovered != self.config['clients']:
                self.config['clients'] = discovered
                self.config_manager.save_config(self.config)

            async with self.tbot.active_clients_lock:
                for session_name in discovered:
                    if session_name not in self.active_clients:
                        session_path = os.path.join(SESSIONS_DIR, session_name)
                        self.active_clients[session_name] = TelegramClient(
                            session_path, API_ID, API_HASH
                        )

            logger.info("Detected %d session(s).", len(discovered))
        except Exception:
            logger.exception("Error detecting sessions")

    async def start_saved_clients(self):
        """
        Start all Telegram client sessions listed in the configuration.
        Ensures clients are authorized and ready to use.

        Account Persistence Behavior:
        - Accounts persist in clients.json and .session files
        - Session files are never auto-deleted; revoked sessions are marked inactive
        - Temporary network/API errors don't delete sessions
        - Accounts remain available for future use
        - Inactive accounts are tracked for admin review
        """
        try:
            # Load session information into active_clients
            await self.detect_sessions()

            # Initialize inactive accounts tracking
            if 'inactive_accounts' not in self.config:
                self.config['inactive_accounts'] = {}

            for session_name, client in list(self.active_clients.items()):
                try:
                    inactive_info = self.config.get('inactive_accounts', {}).get(session_name, {})
                    inactive_reason = inactive_info.get('reason', '') if isinstance(inactive_info, dict) else ''
                    if inactive_reason in {'archived_by_admin', 'session_revoked_or_unavailable', 'not_authorized'}:
                        # Keep the object discoverable but do not reconnect an account
                        # that the administrator explicitly disabled or Telegram rejected.
                        await client.disconnect()
                        async with self.tbot.active_clients_lock:
                            self.tbot.active_clients.pop(session_name, None)
                        logger.info("Skipping inactive session %s (%s); file preserved.", session_name, inactive_reason)
                        continue

                    # Connect client if not already connected
                    if not client.is_connected():
                        await client.connect()

                    # Check if the client is authorized
                    if await client.is_user_authorized():
                        logger.info(f"Successfully loaded and authorized client: {session_name}")
                        # Remove from inactive list if it was there
                        if session_name in self.config['inactive_accounts']:
                            del self.config['inactive_accounts'][session_name]
                            self.config_manager.save_config(self.config)
                        # Ensure session is saved after successful authorization
                        client.session.save()
                    else:
                        # Client reported as unauthorized - check if it's really revoked
                        logger.warning(f"Client {session_name} reported as unauthorized. Checking if it's really revoked...")

                        try:
                            # Try to get a simple dialog to check if session is really revoked
                            await client.get_dialogs(limit=1)
                            logger.info(f"Client {session_name} can still access dialogs despite is_user_authorized() returning False. Keeping in active list.")
                            # Keep the client in active list since it can still function
                        except Exception as check_error:
                            check_error_msg = str(check_error).lower()
                            logger.warning(f"Client {session_name} failed dialog check: {check_error_msg}")

                            # Only consider it truly revoked if we get explicit session errors
                            if ('session' in check_error_msg and ('revoked' in check_error_msg or 'invalid' in check_error_msg)) or 'auth' in check_error_msg:
                                logger.warning(f"Client {session_name} has true SessionRevokedError. Marking inactive without deleting the Session file...")
                                logger.warning(f"This happens when: 1) Account password changed, 2) Account logged out from official app, 3) Telegram security measures")
                                # Remove from active clients first
                                async with self.tbot.active_clients_lock:
                                    if session_name in self.tbot.active_clients:
                                        del self.tbot.active_clients[session_name]
                                await client.disconnect()
                                await self.archive_session(session_name)
                                logger.info(f"Unauthorized session {session_name} has been completely removed")
                            else:
                                # Not a true session revoked error, but client is having issues
                                # KEEP IT IN ACTIVE LIST - don't remove it!
                                logger.warning(f"Client {session_name} has connectivity issues but not revoked. Keeping in active list for retry.")
                                # IMPORTANT: Keep the client in active_clients even if it has issues
                                # This allows it to be retried later

                    # Sleep to avoid hitting Telegram flood limits
                    await asyncio.sleep(3)
                except Exception as e:
                    error_msg = str(e).lower()
                    logger.warning(f"Error loading client {session_name}: {e}")

                    # Only move to inactive for very specific errors
                    # Most errors should be retried rather than making accounts inactive
                    if 'session revoked' in error_msg or 'auth' in error_msg or 'invalid' in error_msg:
                        # True authentication/session errors
                        logger.warning(f"Client {session_name} has authentication issues. Moving to inactive.")
                        async with self.tbot.active_clients_lock:
                            removed_client = self.tbot.active_clients.pop(session_name, None)
                        # Disconnect outside the lock to release the connection
                        # opened earlier (avoids leaking the socket/reader task).
                        if removed_client is not None:
                            try:
                                await removed_client.disconnect()
                            except Exception as disc_err:
                                logger.debug(f"Error disconnecting {session_name}: {disc_err}")

                        if session_name not in self.config['inactive_accounts']:
                            import time as time_module
                            self.config['inactive_accounts'][session_name] = {
                                'phone': session_name,
                                'last_seen': time_module.time(),
                                'reason': 'auth_error',
                                'error_details': str(e)
                            }
                            self.config_manager.save_config(self.config)
                    else:
                        # Temporary errors - keep trying, don't make inactive
                        logger.warning(f"Temporary error with client {session_name}: {e}. Will retry on next startup.")
                        # IMPORTANT: DO NOT remove from active_clients for temporary errors
                        # Keep it in active_clients so it can be retried
                        logger.info(f"Keeping {session_name} in active_clients despite temporary error for future retry")
        except Exception as e:
            logger.error(f"Error in start_saved_clients: {e}")

    async def show_inactive_accounts(self, event):
        """
        Display list of inactive accounts for admin review.
        """
        try:
            logger.info("show_inactive_accounts called")

            # Initialize inactive accounts if not exists
            if 'inactive_accounts' not in self.config:
                self.config['inactive_accounts'] = {}

            inactive_accounts = self.config['inactive_accounts']

            if not inactive_accounts:
                await event.respond("No inactive accounts found. All accounts are working properly.")
                return

            # Build response message
            message = "**Inactive Accounts Report**\n\n"
            message += f"Total inactive accounts: {len(inactive_accounts)}\n\n"

            for phone, account_info in inactive_accounts.items():
                reason = account_info.get('reason', 'unknown')
                last_seen = account_info.get('last_seen', 0)
                error_details = account_info.get('error_details', 'No details available')

                # Format timestamp
                import time
                last_seen_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(last_seen))

                message += f"**{phone}**\n"
                message += f"   Reason: {reason}\n"
                message += f"   Last seen: {last_seen_str}\n"
                message += f"   Error: {error_details[:100]}{'...' if len(error_details) > 100 else ''}\n\n"

            # Add management options
            message += "**Management Options:**\n"
            message += "• Use /start to return to main menu\n"
            message += "• Inactive accounts will be automatically reactivated when possible"

            # Send message (split if too long)
            if len(message) > 4000:
                # Split into chunks
                chunks = []
                current_chunk = ""
                lines = message.split('\n')

                for line in lines:
                    if len(current_chunk + line + '\n') > 4000:
                        chunks.append(current_chunk)
                        current_chunk = line + '\n'
                    else:
                        current_chunk += line + '\n'

                if current_chunk:
                    chunks.append(current_chunk)

                for i, chunk in enumerate(chunks):
                    if i == 0:
                        await event.respond(chunk, buttons=Keyboard.back_button('account_management'))
                    else:
                        await event.respond(f"(Part {i+1}/{len(chunks)})\n{chunk}")
            else:
                await event.respond(message, buttons=Keyboard.back_button('account_management'))

        except Exception as e:
            logger.error(f"Error in show_inactive_accounts: {e}")
            await event.respond("Error retrieving inactive accounts list.", buttons=Keyboard.back_button('account_management'))

    async def reactivate_account(self, event, phone_number):
        """
        Attempt to reactivate an inactive account.
        """
        try:
            logger.info(f"reactivate_account called for {phone_number}")

            if 'inactive_accounts' not in self.config or phone_number not in self.config['inactive_accounts']:
                await event.respond(f"Account {phone_number} is not in inactive accounts list.")
                return

            # Remove from inactive list and try to reload
            del self.config['inactive_accounts'][phone_number]
            self.config_manager.save_config(self.config)

            # Try to reload the account
            try:
                session_file = get_safe_session_file_path(phone_number)
            except ValueError as e:
                logger.error(f"Invalid phone number for session file: {e}")
                await event.respond(f"Invalid phone number format.")
                return
            
            if os.path.exists(session_file):
                try:
                    # Create new client instance
                    from telethon import TelegramClient
                    from src.config import API_ID, API_HASH

                    # Sanitize phone number for use as session name
                    try:
                        sanitized_phone = sanitize_session_name(phone_number)
                    except ValueError as e:
                        logger.error(f"Invalid phone number for session name: {e}")
                        await event.respond(f"Invalid phone number format.")
                        return
                    
                    client = TelegramClient(os.path.join(SESSIONS_DIR, sanitized_phone), API_ID, API_HASH)

                    # Try to connect and authorize
                    await client.connect()
                    if await client.is_user_authorized():
                        # Use the sanitized name as the key, consistent with
                        # detect_sessions/finalize_client_setup and the actual
                        # session file Telethon opens.
                        async with self.tbot.active_clients_lock:
                            self.tbot.active_clients[sanitized_phone] = client

                        # Add back to config without wiping any previously
                        # discovered groups/metadata for this account.
                        if 'clients' not in self.config:
                            self.config['clients'] = {}
                        self.config['clients'].setdefault(sanitized_phone, [])
                        self.config_manager.save_config(self.config)

                        await event.respond(f"Account {phone_number} successfully reactivated!")
                        logger.info(f"Account {phone_number} reactivated successfully")
                    else:
                        await client.disconnect()
                        await event.respond(f"Account {phone_number} is still not authorized. Cannot reactivate.")
                        logger.warning(f"Account {phone_number} still not authorized during reactivation")

                except Exception as e:
                    logger.error(f"Error reactivating account {phone_number}: {e}")
                    await event.respond(f"Error reactivating account {phone_number}: {str(e)}")
            else:
                await event.respond(f"Session file for {phone_number} not found.")
                logger.warning(f"Session file {session_file} not found during reactivation")

        except Exception as e:
            logger.error(f"Error in reactivate_account: {e}")
            await event.respond("Error during account reactivation.")

    async def disconnect_all_clients(self):
        """
        Disconnect all active Telegram clients and clear the active client list.
        """
        try:
            for session_name, client in list(self.active_clients.items()):
                try:
                    # Cleanup handlers before disconnecting to prevent memory leaks
                    if hasattr(self.tbot, 'monitor'):
                        self.tbot.monitor.cleanup_client_handlers(client)
                    await client.disconnect()
                    logger.info(f"Client {session_name} disconnected successfully.")
                except Exception as e:
                    logger.error(f"Error disconnecting client {session_name}: {e}")
            
            # Clear the active_clients dictionary
            self.active_clients.clear()
            logger.info("All clients disconnected successfully.")
        except Exception as e:
            logger.error(f"Error disconnecting clients: {e}")

    async def archive_session(self, session_name):
        """Disable an account in the panel without deleting its Session file."""
        session_name = session_stem(session_name)
        async with self.tbot.active_clients_lock:
            client = self.tbot.active_clients.pop(session_name, None)
        if client is not None:
            try:
                if hasattr(self.tbot, 'monitor'):
                    self.tbot.monitor.cleanup_client_handlers(client)
                await client.disconnect()
            except Exception as exc:
                logger.debug("Error disconnecting archived session %s: %s", session_name, exc)

        self.config.setdefault('inactive_accounts', {})[session_name] = {
            'phone': session_name,
            'last_seen': time.time(),
            'reason': 'archived_by_admin',
            'error_details': 'Disabled from the management panel; Session file preserved.'
        }
        self.config_manager.save_config(self.config)
        logger.info("Session %s archived; Session file preserved.", session_name)


class AccountHandler:
    """
    Handles all account-related operations for the Telegram bot.
    Manages account creation, authentication, and message processing.
    """

    def __init__(self, tbot):
        """
        Initialize AccountHandler with bot instance.

        Args:
            tbot: Bot instance containing configuration and client management
        """
        self.tbot = tbot
        self._conversations = {}
        self.SessionManager = tbot.client_manager

    async def add_account(self, event):
        """
        Initiates the account addition process by requesting phone number.

        Args:
            event: Telegram event containing chat information
        """
        logger.info("add_account in AccountHandler")
        chat_id = event.chat_id
        try:
            await prompt_for_input(
                self.tbot, event,
                "Please enter your phone number:",
                'phone_number_handler'
            )
        except Exception as e:
            logger.error(f"Error in add_account: {e}")
            await self.tbot.tbot.send_message(chat_id, "Error occurred while adding account. Please try again.")

    async def phone_number_handler(self, event):
        """
        Handles phone number verification and initiates client connection.

        Args:
            event: Telegram event containing the phone number
        """
        logger.info("phone_number_handler in AccountHandler")
        chat_id = event.chat_id
        phone_number = event.message.text.strip()
        
        # Validate phone number
        is_valid, error_msg = InputValidator.validate_phone_number(phone_number)
        if not is_valid:
            await self.tbot.tbot.send_message(chat_id, f"{error_msg}\nPlease try again.")
            return
        
        # Sanitize phone number for use as session name
        try:
            sanitized_phone = sanitize_session_name(phone_number)
        except ValueError as e:
            logger.error(f"Invalid phone number format: {e}")
            await self.tbot.tbot.send_message(chat_id, "Invalid phone number format. Please try again.")
            return
        
        try:
            # Create client with sanitized phone number as session name
            logger.info(f"PHONE_NUMBER_HANDLER: Creating client for {phone_number}")
            client = TelegramClient(os.path.join(SESSIONS_DIR, sanitized_phone), API_ID, API_HASH)

            logger.info("PHONE_NUMBER_HANDLER: Connecting to Telegram...")
            await client.connect()

            if not await client.is_user_authorized():
                logger.info("PHONE_NUMBER_HANDLER: Not authorized, sending code request")
                # Send "Please wait..." message first
                wait_message = await self.tbot.tbot.send_message(chat_id, "Please wait...")
                # Send code request to user's phone
                await client.send_code_request(phone_number)
                # Delete the wait message and send the verification code message
                try:
                    await wait_message.delete()
                except Exception as e:
                    logger.debug(f"Failed to delete prompt message: {e}")
                await self.tbot.tbot.send_message(chat_id, "Verification code sent to your Telegram account.\n\nEnter the verification code:")
                async with self.tbot._conversations_lock:
                    self.tbot._conversations[chat_id] = 'code_handler'
                self.tbot.handlers['temp_client'] = client
                self.tbot.handlers['temp_phone'] = phone_number
                logger.info("PHONE_NUMBER_HANDLER: Code request sent successfully")
            else:
                logger.info("PHONE_NUMBER_HANDLER: Already authorized, finalizing setup")
                # Already authorized, finalize setup
                await self.finalize_client_setup(client, phone_number, chat_id)
        except Exception as e:
            logger.error(f"PHONE_NUMBER_HANDLER: Error - {e}")
            await send_error_message(self.tbot, chat_id, e, 'phone')
            self.cleanup_temp_handlers()

    async def code_handler(self, event):
        """
        Processes verification code and completes authentication.

        Args:
            event: Telegram event containing the verification code
        """
        try:
            logger.info("code_handler in AccountHandler")
            chat_id = event.chat_id
            code = event.message.text.strip()
            client = self.tbot.handlers.get('temp_client')
            phone_number = self.tbot.handlers.get('temp_phone')

            if not client or not phone_number:
                await self.tbot.tbot.send_message(chat_id, "Session expired or invalid. Please start over with /start.")
                self.cleanup_temp_handlers()
                return

            # Send processing message
            processing_msg = await self.tbot.tbot.send_message(chat_id, "Verifying code...")
            
            try:
                # Attempt sign in with code
                await client.sign_in(phone=phone_number, code=code)
                
                # ✅ CRITICAL: Verify that login was successful
                if await client.is_user_authorized():
                    logger.info(f"Code verification successful for {phone_number}")
                    await processing_msg.delete()
                    await self.finalize_client_setup(client, phone_number, chat_id)
                else:
                    # Login failed but no exception
                    logger.error(f"Code verification failed for {phone_number}: not authorized after sign_in")
                    await processing_msg.delete()
                    await self.tbot.tbot.send_message(chat_id, "Code verification failed. Please try again with /start.")
                    self.cleanup_temp_handlers()
                    
            except Exception as sign_in_error:
                # Delete processing message
                try:
                    await processing_msg.delete()
                except Exception as e:
                    logger.debug(f"Failed to delete prompt message: {e}")
                # Re-raise to be handled by outer exception handlers
                raise sign_in_error
                
        except SessionPasswordNeededError:
            await self.tbot.tbot.send_message(chat_id, "Two-factor authentication is enabled.\n\nPlease enter your password:")
            async with self.tbot._conversations_lock:
                self.tbot._conversations[chat_id] = 'password_handler'
        except FloodWaitError as e:
            await self.tbot.tbot.send_message(chat_id, f"Too many attempts. Please wait {e.seconds} seconds and try again.")
            self.cleanup_temp_handlers()
        except Exception as e:
            logger.error(f"Error during code verification: {e}")
            await send_error_message(self.tbot, chat_id, e, 'code')
            self.cleanup_temp_handlers()

    async def password_handler(self, event):
        """
        Handles 2FA password verification if required.

        Args:
            event: Telegram event containing the 2FA password
        """
        try:
            logger.info("password_handler in AccountHandler")
            chat_id = event.chat_id
            password = event.message.text.strip()
            client = self.tbot.handlers.get('temp_client')
            phone_number = self.tbot.handlers.get('temp_phone')

            if not client or not phone_number:
                await self.tbot.tbot.send_message(chat_id, "Session expired or invalid. Please start over with /start.")
                self.cleanup_temp_handlers()
                return

            # Send processing message
            processing_msg = await self.tbot.tbot.send_message(chat_id, "Verifying password...")
            
            try:
                # Attempt sign in with password
                await client.sign_in(password=password)
                
                # ✅ CRITICAL: Verify that login was successful
                if await client.is_user_authorized():
                    logger.info(f"Password verification successful for {phone_number}")
                    await processing_msg.delete()
                    await self.finalize_client_setup(client, phone_number, chat_id)
                else:
                    # Login failed but no exception
                    logger.error(f"Password verification failed for {phone_number}: not authorized after sign_in")
                    await processing_msg.delete()
                    await self.tbot.tbot.send_message(chat_id, "Password verification failed. Please try again with /start.")
                    self.cleanup_temp_handlers()
                    
            except Exception as sign_in_error:
                # Delete processing message
                try:
                    await processing_msg.delete()
                except Exception as e:
                    logger.debug(f"Failed to delete prompt message: {e}")
                # Re-raise to be handled by outer exception handlers
                raise sign_in_error
                
        except FloodWaitError as e:
            await self.tbot.tbot.send_message(chat_id, f"Too many attempts. Please wait {e.seconds} seconds and try again.")
            self.cleanup_temp_handlers()
        except Exception as e:
            logger.error(f"Error during password verification: {e}")
            await send_error_message(self.tbot, chat_id, e, 'password')
            self.cleanup_temp_handlers()

    async def finalize_client_setup(self, client, phone_number, chat_id):
        """
        Completes client setup and saves configuration.

        Args:
            client: Authorized TelegramClient instance
            phone_number: User's phone number
            chat_id: Chat ID for response messages
        """
        logger.info("finalize_client_setup in AccountHandler")
        try:
            # ✅ DOUBLE CHECK: Make absolutely sure the client is authorized before saving
            if not await client.is_user_authorized():
                logger.error(f"CRITICAL: Client {phone_number} is NOT authorized in finalize_client_setup!")
                await self.tbot.tbot.send_message(chat_id, "Authentication failed. Account is not properly authorized.\n\nPlease try again with /start.")
                self.cleanup_temp_handlers()
                return
            
            # ✅ Verify we can get user info
            try:
                me = await client.get_me()
                if not me:
                    logger.error(f"CRITICAL: get_me() returned None for {phone_number}")
                    await self.tbot.tbot.send_message(chat_id, "Authentication verification failed.\n\nPlease try again with /start.")
                    self.cleanup_temp_handlers()
                    return
                logger.info(f"Verified user: {me.first_name} (@{me.username}) - ID: {me.id}")
            except Exception as verify_error:
                logger.error(f"CRITICAL: Cannot verify user {phone_number}: {verify_error}")
                await self.tbot.tbot.send_message(chat_id, f"Authentication verification failed: {verify_error}\n\nPlease try again with /start.")
                self.cleanup_temp_handlers()
                return
            
            # ✅ NOW save the session (only after all checks passed)
            # Use sanitized phone number as session name
            try:
                session_name = sanitize_session_name(phone_number)
            except ValueError as e:
                logger.error(f"Invalid phone number for session name: {e}")
                await self.tbot.tbot.send_message(chat_id, "Invalid phone number format.")
                self.cleanup_temp_handlers()
                return
            
            client.session.save()
            logger.info(f"Session saved for {phone_number}")

            if not isinstance(self.tbot.config['clients'], dict):
                logger.warning("'clients' is not a dictionary. Initializing it as an empty dictionary.")
                self.tbot.config['clients'] = {}

            self.tbot.config['clients'][session_name] = []
            self.tbot.config_manager.save_config(self.tbot.config)
            logger.info(f"Config saved for {phone_number}")

            # Use lock when modifying active_clients
            async with self.tbot.active_clients_lock:
                self.tbot.active_clients[session_name] = client
            logger.info(f"Added to active_clients: {phone_number}")
            
            # Set up message monitoring for this new client
            if not hasattr(client, '_message_processing_set'):
                await self.tbot.monitor.process_messages_for_client(client)
                client._message_processing_set = True

            await self.tbot.tbot.send_message(
                chat_id, 
                f"Account added successfully!\n\n"
                f"Phone: {phone_number}\n"
                f"Name: {me.first_name}\n"
                f"Username: @{me.username if me.username else 'N/A'}\n\n"
                f"Account is now active and ready to use!"
            )
            logger.info(f"Account {phone_number} fully set up and verified")
            self.cleanup_temp_handlers()

        except Exception as e:
            logger.error(f"Error in finalize_client_setup: {e}", exc_info=True)
            await self.tbot.tbot.send_message(chat_id, f"Error occurred while finalizing setup: {str(e)[:100]}")
            self.cleanup_temp_handlers()

    def cleanup_temp_handlers(self):
        """
        Removes temporary handlers and data after setup completion.
        """
        logger.info("cleanup_temp_handlers in AccountHandler")
        try:
            self.tbot.handlers.pop('temp_client', None)
            self.tbot.handlers.pop('temp_phone', None)
        except Exception as e:
            logger.error(f"Error in cleanup_temp_handlers: {e}")

    async def update_groups(self, event):
        """
        Updates group information for all clients.

        Args:
            event: Telegram event triggering the update
        """
        logger.info("Started update_groups process.")
        groups_per_client = {}
        await self.SessionManager.detect_sessions()

        try:
            status_message = await event.respond("Please wait, identifying groups for each client...")

            json_data = {
                "TARGET_GROUPS": [],
                "KEYWORDS": [],
                "IGNORE_USERS": [],
                "clients": {}
            }

            if os.path.exists(CLIENTS_JSON_PATH):
                try:
                    with open(CLIENTS_JSON_PATH, "r", encoding='utf-8') as json_file:
                        loaded_data = json.loads(json_file.read())
                        json_data.update(loaded_data)
                    logger.info("Loaded existing client data from clients.json.")
                except json.JSONDecodeError as e:
                    logger.error("Error decoding clients.json.", exc_info=True)

            # Normalize the clients section to dict format regardless of where it
            # came from (missing file, legacy list format, or new dict format).
            if isinstance(json_data["clients"], list):
                json_data["clients"] = {session: [] for session in json_data["clients"]}
            elif not isinstance(json_data["clients"], dict):
                json_data["clients"] = {}

            # Get a snapshot of active clients to avoid holding the lock during long operations
            async with self.tbot.active_clients_lock:
                active_clients_snapshot = list(self.tbot.active_clients.items())
            
            for session_name, client in active_clients_snapshot:
                try:
                    logger.info(f"Processing client: {session_name}")
                    group_ids = set()

                    # Process dialogs in batches for better performance
                    batch_count = 0
                    dialog_limit = 5000  # Reasonable limit to prevent excessive processing
                    
                    async for dialog in client.iter_dialogs(limit=dialog_limit):
                        try:
                            if isinstance(dialog.entity, (Chat, Channel)) and not (
                                isinstance(dialog.entity, Channel) and dialog.entity.broadcast
                            ):
                                group_ids.add(dialog.entity.id)
                            
                            batch_count += 1
                            
                            # Rate limiting and progress updates
                            if batch_count % GROUPS_BATCH_SIZE == 0:
                                await asyncio.sleep(1)  # Shorter sleep for better responsiveness
                                
                            if len(group_ids) % 20 == 0:
                                await status_message.edit(f"Found {len(group_ids)} groups for {session_name}...")
                                
                        except Exception as e:
                            logger.error(f"Error processing dialog for client {session_name}.", exc_info=True)
                            continue

                    groups_per_client[session_name] = list(group_ids)
                    logger.info(f"Found {len(group_ids)} groups for client {session_name}.")
                    await status_message.edit(f"Found {len(group_ids)} groups for {session_name}.")
                    await asyncio.sleep(GROUPS_UPDATE_SLEEP)

                except FloodWaitError as e:
                    wait_time = e.seconds
                    logger.warning(f"FloodWaitError: Sleeping for {wait_time} seconds for client {session_name}.")
                    await status_message.edit(f"Rate limited. Waiting for {wait_time} seconds...")
                    await asyncio.sleep(wait_time)
                    continue
                except Exception as e:
                    error_msg = str(e).lower()
                    # Check if session is revoked
                    from src.utils import is_session_revoked_error, remove_revoked_session_completely
                    if is_session_revoked_error(e):
                        logger.error(f"Session revoked while updating groups for {session_name}: {e}")
                        await remove_revoked_session_completely(self.tbot, session_name)
                        continue
                    logger.error(f"Unexpected error while processing client {session_name}.", exc_info=True)
                    continue

            for session_name, group_ids in groups_per_client.items():
                existing = json_data["clients"].get(session_name)
                if isinstance(existing, dict):
                    # New format: preserve metadata (e.g. is_reported) and merge groups
                    existing_groups = existing.get('groups', [])
                    existing['groups'] = list(set(existing_groups + group_ids))
                    json_data["clients"][session_name] = existing
                elif isinstance(existing, list):
                    json_data["clients"][session_name] = list(set(existing + group_ids))
                else:
                    json_data["clients"][session_name] = group_ids

            with open(CLIENTS_JSON_PATH, "w", encoding='utf-8') as json_file:
                json.dump(json_data, json_file, indent=4, ensure_ascii=False)
                logger.info(f"Saved updated client data for {len(groups_per_client)} clients to clients.json.")

            await status_message.edit(f"That's it, groups identified and saved successfully for all clients!")

        except Exception as e:
            logger.error("Critical error in update_groups function.", exc_info=True)
            await event.respond(f"Error identifying groups: {str(e)}")


    async def check_all_accounts_report_status(self, event):
        """
        Check report status for all existing accounts.
        """
        if not REPORT_CHECK_BOT:
            await event.respond("REPORT_CHECK_BOT not configured. Please set it in start_bot.py or .env file.")
            return
        
        try:
            await event.respond("Checking report status for all accounts... This may take a while.")
            
            clients_data = self.tbot.config.get('clients', {})
            if not clients_data:
                await event.respond("No accounts found to check.")
                return
            
            reported_accounts = []
            checked_count = 0
            
            # Only check accounts that are in active_clients (skip revoked sessions)
            async with self.tbot.active_clients_lock:
                active_sessions = set(self.tbot.active_clients.keys())
                sessions_to_check = [s for s in clients_data.keys() if s in active_sessions]
            
            for session_name in sessions_to_check:
                try:
                    # Get phone number from session name
                    phone_number = session_name.replace('.session', '').strip()
                    if not phone_number.startswith('+'):
                        phone_number = '+' + phone_number
                    
                    # Get account client
                    async with self.tbot.active_clients_lock:
                        account = self.tbot.active_clients.get(session_name)
                    
                    if account:
                        checked_count += 1
                        # Check report status
                        from src.actions import Actions
                        actions = Actions(self.tbot)
                        is_reported = await actions.check_report_status(phone_number, account)
                        
                        if is_reported:
                            reported_accounts.append(session_name)
                            # Save report status to config
                            if not isinstance(clients_data[session_name], dict):
                                old_groups = clients_data[session_name]
                                clients_data[session_name] = {
                                    'groups': old_groups if isinstance(old_groups, list) else [],
                                    'is_reported': True
                                }
                            else:
                                clients_data[session_name]['is_reported'] = True
                            
                            # Save config
                            self.tbot.config_manager.save_config(self.tbot.config)
                            logger.info(f"Marked {session_name} as reported in config")
                        
                        # Small delay between checks
                        await asyncio.sleep(1)
                except Exception as e:
                    logger.error(f"Error checking report status for {session_name}: {e}")
            
            # Report results
            if reported_accounts:
                reported_phones = [acc.replace('.session', '') for acc in reported_accounts]
                result_msg = f"Checked {checked_count} accounts.\n\nReported accounts: {', '.join(reported_phones)}"
            else:
                result_msg = f"Checked {checked_count} accounts.\n\nNo reported accounts found."
            
            await event.respond(result_msg)
            
        except Exception as e:
            logger.error(f"Error in check_all_accounts_report_status: {e}", exc_info=True)
            await event.respond(f"Error checking accounts: {str(e)}")

    async def show_accounts(self, event):
        """Show all discovered accounts through the reply keyboard."""
        try:
            async with self.tbot.active_clients_lock:
                active = set(self.tbot.active_clients.keys())

            clients = self.tbot.config.get('clients', {})
            inactive = self.tbot.config.get('inactive_accounts', {})
            sessions = sorted(set(clients) | set(inactive))
            if not sessions:
                await Keyboard.edit_or_respond(event, "No Session files were found in the sessions directory.", buttons=Keyboard.back_button('account_management'))
                return

            lines = [
                "👤 <b>Telegram Accounts</b>", "",
                f"Total: <b>{len(sessions)}</b>",
                f"Active: <b>{len(active & set(sessions))}</b>", "",
                "Select an account:"
            ]
            labels = []
            mapping = {}
            for session in sessions:
                is_active = session in active
                info = inactive.get(session, {})
                marker = "🟢" if is_active else "🟡"
                meta = clients.get(session, {})
                phone = meta.get('phone') if isinstance(meta, dict) else None
                label_value = phone or session
                if not phone and session.isdigit():
                    label_value = session
                label = f"{marker} {label_value}"
                if not is_active and info.get('reason'):
                    label += f" · {info.get('reason')}"
                label = label[:64]
                labels.append(label)
                mapping[label] = session

            self.tbot._ui_context[event.chat_id] = {'menu': 'accounts', 'accounts': mapping}
            await Keyboard.edit_or_respond(event, "\n".join(lines), buttons=Keyboard.account_list_keyboard(labels))
        except Exception as exc:
            logger.exception("Error showing accounts")
            await Keyboard.edit_or_respond(event, f"Could not load accounts.\n\n{str(exc)[:220]}", buttons=Keyboard.back_button('account_management'))

    async def _get_client(self, session: str):
        """Return an active client for a normalized session name."""
        name = session_stem(session)
        async with self.tbot.active_clients_lock:
            return self.tbot.active_clients.get(name)

    async def show_account_detail(self, event, session: str):
        try:
            name = session_stem(session)
            client = await self._get_client(name)
            active = client is not None
            inactive_info = self.tbot.config.get('inactive_accounts', {}).get(name, {})
            reason = inactive_info.get('reason', 'not connected')

            meta = self.tbot.config.get('clients', {}).get(name, {})
            phone = meta.get('phone') if isinstance(meta, dict) else None
            text = f"👤 <b>Account</b>\n\n<b>Phone:</b> {phone or 'Unknown'}\n<b>Session:</b> {name}\n"
            text += f"<b>Status:</b> {'🟢 Connected' if active else '🟡 Inactive'}\n"
            if not active:
                text += f"<b>Reason:</b> {reason}\n"

            if active:
                try:
                    me = await client.get_me()
                    text += f"<b>User ID:</b> {me.id}\n"
                    if getattr(me, 'username', None):
                        text += f"<b>Username:</b> @{me.username}\n"
                    if getattr(me, 'first_name', None):
                        text += f"<b>Name:</b> {me.first_name}"
                        if getattr(me, 'last_name', None):
                            text += f" {me.last_name}"
                        text += "\n"
                    dc_id = getattr(getattr(client, 'session', None), 'dc_id', None)
                    if dc_id:
                        text += f"<b>Data Center:</b> {dc_id}\n"
                except Exception as exc:
                    text += f"\n⚠️ Profile read failed: {str(exc)[:120]}"
            else:
                path = get_safe_session_file_path(name)
                text += f"<b>Session file:</b> {os.path.basename(path)}\n"
                text += "The Session file is preserved."

            self.tbot._ui_context[event.chat_id] = {'menu': 'account_detail', 'session': name}
            await Keyboard.edit_or_respond(
                event, text, buttons=Keyboard.account_detail_keyboard(name, active)
            )
        except Exception:
            logger.exception("Error showing account detail")
            await Keyboard.edit_or_respond(event, "Could not load account details.", buttons=Keyboard.back_button('list_accounts'))

    async def show_profile(self, event, session: str):
        client = await self._get_client(session)
        if client is None:
            await Keyboard.edit_or_respond(event, "Account is not connected.", buttons=Keyboard.back_button(f"account_detail_{session_stem(session)}"))
            return
        try:
            me = await client.get_me()
            username = f"@{me.username}" if getattr(me, 'username', None) else "No username"
            name = " ".join(x for x in [getattr(me, 'first_name', None), getattr(me, 'last_name', None)] if x) or "No name"
            text = (
                "👤 <b>Profile</b>\n\n"
                f"<b>ID:</b> {me.id}\n"
                f"<b>Name:</b> {name}\n"
                f"<b>Username:</b> {username}\n"
                f"<b>Phone:</b> {getattr(me, 'phone', None) or 'Hidden'}\n"
                f"<b>Bot:</b> {'Yes' if getattr(me, 'bot', False) else 'No'}\n"
                f"<b>Bio:</b> {(getattr(me, 'about', None) or '—')[:250]}"
            )
            await Keyboard.edit_or_respond(
                event, text,
                buttons=Keyboard.back_button(f"account_detail_{session_stem(session)}")
            )
        except Exception as exc:
            await Keyboard.edit_or_respond(
                event, f"Could not read profile.\n\n{str(exc)[:200]}",
                buttons=Keyboard.back_button(f"account_detail_{session_stem(session)}")
            )

    async def show_memberships(self, event, session: str, kind: str):
        """Show groups/channels for one account with reply-keyboard navigation."""
        client = await self._get_client(session)
        name = session_stem(session)
        if client is None:
            self.tbot._ui_context[event.chat_id] = {'menu': 'account_detail', 'session': name}
            await Keyboard.edit_or_respond(event, "Account is not connected.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            return
        try:
            rows = []
            async for dialog in client.iter_dialogs(limit=200):
                is_group = bool(getattr(dialog, 'is_group', False))
                is_channel = bool(getattr(dialog, 'is_channel', False))
                if kind == 'groups' and not is_group:
                    continue
                if kind == 'channels' and not is_channel:
                    continue
                entity = dialog.entity
                title = (dialog.name or "Unnamed").replace('\n', ' ')[:42]
                username = getattr(entity, 'username', None)
                suffix = f"  @{username}" if username else ""
                rows.append(f"• {title}{suffix}")

            label = "👥 Groups" if kind == 'groups' else "📢 Channels"
            text = f"<b>{label}</b>\n\n" + ("\n".join(rows[:40]) if rows else "No memberships found.")
            if len(rows) > 40:
                text += f"\n\nShowing 40 of {len(rows)}."
            self.tbot._ui_context[event.chat_id] = {'menu': 'membership', 'session': name, 'kind': kind}
            await Keyboard.edit_or_respond(event, text, buttons=Keyboard.membership_keyboard(name, kind))
        except Exception as exc:
            logger.exception("Could not load %s for %s", kind, name)
            self.tbot._ui_context[event.chat_id] = {'menu': 'account_detail', 'session': name}
            await Keyboard.edit_or_respond(event, f"Could not load {kind}.\n\n{str(exc)[:180]}", buttons=Keyboard.back_button(f"account_detail_{name}"))

    async def show_edit_profile(self, event, session: str):
        name = session_stem(session)
        client = await self._get_client(name)
        if client is None:
            await Keyboard.edit_or_respond(event, "Account is not connected.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            return
        self.tbot._ui_context[event.chat_id] = {'menu': 'edit_profile', 'session': name}
        await Keyboard.edit_or_respond(event, "📝 <b>Edit Profile</b>\n\nChoose what you want to change:", buttons=Keyboard.edit_profile_keyboard(name))

    async def edit_name_prompt(self, event, session: str):
        name = session_stem(session)
        if await self._get_client(name) is None:
            await Keyboard.edit_or_respond(event, "Account is not connected.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            return
        self.tbot.handlers['profile_edit_session'] = name
        self.tbot.handlers['profile_edit_kind'] = 'name'
        await prompt_for_input(self.tbot, event, "Send the new first name. You can use: First Name | Last Name", 'profile_edit_handler')

    async def edit_username_prompt(self, event, session: str):
        name = session_stem(session)
        if await self._get_client(name) is None:
            await Keyboard.edit_or_respond(event, "Account is not connected.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            return
        self.tbot.handlers['profile_edit_session'] = name
        self.tbot.handlers['profile_edit_kind'] = 'username'
        await prompt_for_input(self.tbot, event, "Send the new username without @. To remove it, send -", 'profile_edit_handler')

    async def edit_photo_prompt(self, event, session: str):
        name = session_stem(session)
        if await self._get_client(name) is None:
            await Keyboard.edit_or_respond(event, "Account is not connected.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            return
        self.tbot.handlers['profile_edit_session'] = name
        self.tbot.handlers['profile_edit_kind'] = 'photo'
        await prompt_for_input(self.tbot, event, "Send the new profile photo as an image.", 'profile_edit_handler')

    async def profile_edit_handler(self, event):
        name = self.tbot.handlers.get('profile_edit_session')
        kind = self.tbot.handlers.get('profile_edit_kind')
        client = await self._get_client(name) if name else None
        if client is None or not kind:
            await event.respond("Profile edit session expired. Please open the account again.")
            self.cleanup_temp_handlers()
            return
        try:
            if kind == 'name':
                value = (event.message.text or '').strip()
                parts = [p.strip() for p in value.split('|', 1)]
                first = parts[0][:64]
                last = parts[1][:64] if len(parts) > 1 else ''
                if not first:
                    await event.respond("First name cannot be empty.")
                    return
                await client(UpdateProfileRequest(first_name=first, last_name=last))
                await event.respond("✅ Name updated.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            elif kind == 'username':
                username = (event.message.text or '').strip().lstrip('@')
                if username == '-':
                    username = ''
                if username and not username.replace('_', '').isalnum():
                    await event.respond("Invalid username format.")
                    return
                await client(UpdateUsernameRequest(username=username))
                await event.respond("✅ Username updated.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            elif kind == 'photo':
                if not event.message.photo and not event.message.media:
                    await event.respond("Please send an image/photo.")
                    return
                data = BytesIO()
                await client.download_media(event.message, file=data)
                data.seek(0)
                uploaded = await client.upload_file(data, file_name='profile.jpg')
                await client(UploadProfilePhotoRequest(file=uploaded))
                await event.respond("✅ Profile photo updated.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            await cleanup_conversation_state(self.tbot, event.chat_id)
            self.cleanup_temp_handlers()
        except Exception as exc:
            logger.exception("Profile edit failed for %s", name)
            await event.respond(f"❌ Profile update failed.\n\n{str(exc)[:220]}")

    async def send_profile_photo(self, event, session: str):
        name = session_stem(session)
        client = await self._get_client(name)
        if client is None:
            await Keyboard.edit_or_respond(event, "Account is not connected.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            return
        try:
            data = BytesIO()
            result = await client.download_profile_photo('me', file=data)
            if not result:
                await Keyboard.edit_or_respond(event, "This account has no profile photo.", buttons=Keyboard.back_button(f"account_detail_{name}"))
                return
            data.seek(0)
            await event.respond(file=data, message=f"🖼 Profile photo — {name}", buttons=Keyboard.back_button(f"account_detail_{name}"))
        except Exception as exc:
            logger.exception("Could not load profile photo for %s", name)
            await Keyboard.edit_or_respond(event, f"Could not load profile photo.\n\n{str(exc)[:180]}", buttons=Keyboard.back_button(f"account_detail_{name}"))

    async def join_account_prompt(self, event, session: str):
        name = session_stem(session)
        if await self._get_client(name) is None:
            await Keyboard.edit_or_respond(event, "Account is not connected.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            return
        self.tbot.handlers['account_membership_session'] = name
        self.tbot.handlers['account_membership_action'] = 'join'
        await prompt_for_input(self.tbot, event, "Send the group/channel link or @username to join.", 'account_membership_handler')

    async def leave_account_prompt(self, event, session: str):
        name = session_stem(session)
        if await self._get_client(name) is None:
            await Keyboard.edit_or_respond(event, "Account is not connected.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            return
        self.tbot.handlers['account_membership_session'] = name
        self.tbot.handlers['account_membership_action'] = 'leave'
        await prompt_for_input(self.tbot, event, "Send the group/channel link or @username to leave.", 'account_membership_handler')

    async def account_membership_handler(self, event):
        name = self.tbot.handlers.get('account_membership_session')
        action = self.tbot.handlers.get('account_membership_action')
        client = await self._get_client(name) if name else None
        if client is None or action not in {'join', 'leave'}:
            await event.respond("Membership operation expired. Open the account again.")
            self.cleanup_temp_handlers()
            return
        link = (event.message.text or '').strip()
        valid, err = InputValidator.validate_telegram_link(link)
        if not valid:
            await event.respond(f"{err}\nPlease try again.")
            return
        try:
            target = link
            if action == 'join':
                if '/+' in link or 't.me/+' in link:
                    invite_hash = link.rstrip('/').split('/')[-1].lstrip('+')
                    await client(ImportChatInviteRequest(invite_hash))
                else:
                    entity = await client.get_entity(target)
                    await client(JoinChannelRequest(entity))
                await event.respond("✅ Account joined successfully.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            else:
                entity = await client.get_entity(target)
                if isinstance(entity, Channel):
                    await client(LeaveChannelRequest(entity))
                elif isinstance(entity, Chat):
                    me = await client.get_me()
                    await client(DeleteChatUserRequest(chat_id=entity.id, user_id=me.id))
                else:
                    await event.respond("This target is not a group or channel.")
                    return
                await event.respond("✅ Account left successfully.", buttons=Keyboard.back_button(f"account_detail_{name}"))
            await cleanup_conversation_state(self.tbot, event.chat_id)
            self.cleanup_temp_handlers()
        except FloodWaitError as exc:
            await event.respond(f"Telegram rate limit: wait {exc.seconds} seconds.")
        except Exception as exc:
            logger.exception("Membership operation failed for %s", name)
            await event.respond(f"❌ Operation failed.\n\n{str(exc)[:220]}")

    async def show_dialogs(self, event, session: str):
        client = await self._get_client(session)
        if client is None:
            await Keyboard.edit_or_respond(event, "Account is not connected.", buttons=Keyboard.back_button(f"account_detail_{session_stem(session)}"))
            return
        try:
            rows = []
            async for dialog in client.iter_dialogs(limit=15):
                title = (dialog.name or "Unnamed").replace("\n", " ")[:42]
                unread = getattr(dialog, 'unread_count', 0) or 0
                kind = "Group" if getattr(dialog, 'is_group', False) else ("Channel" if getattr(dialog, 'is_channel', False) else "Chat")
                rows.append(f"• {title} — {kind}" + (f" · {unread} unread" if unread else ""))
            text = "💬 <b>Recent Dialogs</b>\n\n" + ("\n".join(rows) if rows else "No dialogs found.")
            await Keyboard.edit_or_respond(event, text, buttons=Keyboard.back_button(f"account_detail_{session_stem(session)}"))
        except Exception as exc:
            await Keyboard.edit_or_respond(event, f"Could not read dialogs.\n\n{str(exc)[:200]}", buttons=Keyboard.back_button(f"account_detail_{session_stem(session)}"))

    async def reconnect_one(self, event, session: str):
        name = session_stem(session)
        try:
            path = get_safe_session_file_path(name)
            if not os.path.exists(path):
                await event.respond(f"Session file for {name} was not found. No file was deleted.")
                return

            async with self.tbot.active_clients_lock:
                old = self.tbot.active_clients.pop(name, None)
            if old is not None:
                try:
                    if hasattr(self.tbot, 'monitor'):
                        self.tbot.monitor.cleanup_client_handlers(old)
                    await old.disconnect()
                except Exception:
                    logger.debug("Error disconnecting old client %s", name, exc_info=True)

            client = TelegramClient(os.path.join(SESSIONS_DIR, name), API_ID, API_HASH)
            await client.connect()
            if not await client.is_user_authorized():
                await client.disconnect()
                self._mark_inactive(name, 'not_authorized', 'Session exists but is not authorized.')
                await event.respond(f"{name} is not authorized. Session file was preserved.")
                return

            async with self.tbot.active_clients_lock:
                self.tbot.active_clients[name] = client
            self.config.setdefault('clients', {}).setdefault(name, [])
            self.config.get('inactive_accounts', {}).pop(name, None)
            self.config_manager.save_config(self.config)
            await event.respond(f"✅ {name} reconnected. Session file preserved.")
        except Exception as exc:
            logger.error("Reconnect failed for %s: %s", name, exc, exc_info=True)
            self._mark_inactive(name, 'connection_error', str(exc))
            await event.respond(f"Could not reconnect {name}. Session file was preserved.")

    async def reconnect_all(self, event):
        sessions = sorted(self.tbot.config.get('clients', {}))
        if not sessions:
            await event.respond("No accounts are configured.")
            return
        success = 0
        failed = 0
        for session in sessions:
            try:
                # Reuse the single-account routine without requiring a new message
                path = get_safe_session_file_path(session)
                if not os.path.exists(path):
                    failed += 1
                    continue
                await self._reconnect_silent(session)
                success += 1
            except Exception as exc:
                failed += 1
                self._mark_inactive(session, 'connection_error', str(exc))
        await event.respond(f"Reconnect finished.\n\nConnected: {success}\nFailed: {failed}\n\nNo Session file was deleted.")

    async def _reconnect_silent(self, session: str):
        name = session_stem(session)
        async with self.tbot.active_clients_lock:
            old = self.tbot.active_clients.pop(name, None)
        if old is not None:
            try:
                if hasattr(self.tbot, 'monitor'):
                    self.tbot.monitor.cleanup_client_handlers(old)
                await old.disconnect()
            except Exception:
                pass
        client = TelegramClient(os.path.join(SESSIONS_DIR, name), API_ID, API_HASH)
        await client.connect()
        if not await client.is_user_authorized():
            await client.disconnect()
            raise RuntimeError("Session is not authorized")
        async with self.tbot.active_clients_lock:
            self.tbot.active_clients[name] = client
        self.config.setdefault('clients', {}).setdefault(name, [])
        self.config.setdefault('inactive_accounts', {}).pop(name, None)
        self.config_manager.save_config(self.config)


    TRANSIENT_ERRORS = (
        (('database is locked', 'sqlite'), 'database issue', 'Database lock'),
        (('flood', 'too many'), 'Telegram limit', 'Flood control'),
        (('network', 'connection'), 'network issue', 'Network issue'),
    )

    def _mark_inactive(self, session: str, reason: str, details: str):
        self.tbot.config.setdefault('inactive_accounts', {})[session] = {
            'phone': session,
            'last_seen': time.time(),
            'reason': reason,
            'error_details': details,
        }
        self.tbot.config_manager.save_config(self.tbot.config)

    async def _disable_client(self, session: str, event):
        async with self.tbot.active_clients_lock:
            client = self.tbot.active_clients[session]
            if hasattr(self.tbot, 'monitor'):
                self.tbot.monitor.cleanup_client_handlers(client)
            await client.disconnect()
            del self.tbot.active_clients[session]
        logger.info(f"Client {session} disabled successfully.")
        await event.respond(f"Account {session} disabled.")

    async def _activate_authorized_client(self, session: str, client, event):
        async with self.tbot.active_clients_lock:
            self.tbot.active_clients[session] = client

        if hasattr(self.tbot, 'monitor') and not hasattr(client, '_message_processing_set'):
            await self.tbot.monitor.process_messages_for_client(client)
            client._message_processing_set = True

        logger.info(f"Client {session} enabled successfully.")
        await event.respond(f"Account {session} activated.")

        inactive = self.tbot.config.get('inactive_accounts', {})
        if session in inactive:
            del inactive[session]
            self.tbot.config_manager.save_config(self.tbot.config)

    async def _handle_enable_error(self, session: str, error: Exception, event):
        error_msg = str(error).lower()
        logger.error(f"Error enabling client {session}: {error}")

        for needles, user_reason, log_reason in self.TRANSIENT_ERRORS:
            if any(needle in error_msg for needle in needles):
                await event.respond(
                    f"Account {session} is temporarily inactive ({user_reason}). Please try again later.")
                logger.warning(f"{log_reason} for {session}, will retry later")
                return

        self._mark_inactive(session, 'connection_error', str(error))
        await event.respond(f"Error activating account {session}: {str(error)[:100]}...")

    async def _enable_client(self, session: str, event):
        try:
            session_file = get_safe_session_file_path(session)
        except ValueError as e:
            logger.error(f"Invalid session name: {e}")
            await event.respond("Invalid session name format.")
            return

        if not os.path.exists(session_file):
            await event.respond(f"Session file for account {session} not found.")
            logger.error(f"Session file {session_file} not found")
            return

        client = TelegramClient(os.path.join(SESSIONS_DIR, session_stem(session)), API_ID, API_HASH)
        try:
            await client.connect()
            if await client.is_user_authorized():
                await self._activate_authorized_client(session, client, event)
                return

            await client.disconnect()
            self._mark_inactive(session, 'not_authorized_on_reactivation', 'Client not authorized')
            await event.respond(f"Account {session} has been unauthorized by Telegram.")
            logger.warning(f"Client {session} not authorized on reactivation")
        except Exception as e:
            await client.disconnect()
            await self._handle_enable_error(session, e, event)

    async def toggle_client(self, session: str, event):
        """
        Toggle the active/inactive status of a client account.

        Args:
            session (str): Session identifier for the account
            event: Telegram event triggering the toggle
        """
        logger.info(f"toggle_client called for session: {session}")
        try:
            if session not in self.tbot.config['clients']:
                logger.warning(f"Session {session} not found in clients.")
                await event.respond("Account not found.")
                return

            async with self.tbot.active_clients_lock:
                currently_active = session in self.tbot.active_clients

            logger.info(f"Current status for {session}: {'Active' if currently_active else 'Inactive'}")

            if currently_active:
                await self._disable_client(session, event)
            else:
                try:
                    await self._enable_client(session, event)
                except Exception as e:
                    logger.error(f"Error in toggle_client enable section: {e}")
                    await event.respond(f"Error activating account {session}.")

            logger.info("Saving updated configuration.")
            self.tbot.config_manager.save_config(self.tbot.config)

        except Exception as e:
            logger.error(f"Error toggling client {session}: {e}", exc_info=True)
            try:
                await event.respond("Error changing account status.")
            except Exception as resp_e:
                logger.error(f"Failed to send error response: {resp_e}")

    async def archive_client(self, session: str, event):
        """Disable an account without deleting its session file or credentials."""
        try:
            await self.SessionManager.archive_session(session)
            await event.respond(
                f"Account {session} disabled.\n\n"
                "The Session file was preserved and can be re-enabled later."
            )
        except Exception as exc:
            logger.error("Error archiving account %s: %s", session, exc, exc_info=True)
            await event.respond("Could not disable the account.")

