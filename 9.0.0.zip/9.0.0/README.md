# Telegram Account Manager — Preserved Session Edition

This build combines the original Telegram Account Manager with the GitHub
Telegram Panel architecture.

## Important behavior

- Existing `.session` files in `sessions/` are discovered automatically.
- The three supplied sessions are included unchanged.
- Existing sessions are reused; they do not require a new login.
- Session files are **never automatically deleted**.
- "Disable" / "Archive" only disconnects an account and preserves its Session.
- A revoked or unavailable session is marked inactive instead of being deleted.
- "Reconnect" uses the existing Session file.

## Main features

### Account Management
- Discover existing sessions
- Add a new Telegram account
- List all accounts
- Account status
- Profile information
- Recent dialogs
- Reconnect one account
- Reconnect all accounts
- Enable / disable an account
- Preserve sessions when disabled or revoked
- Inactive account tracking

### Individual tools
- Reaction
- Send private message
- Join chat
- Leave chat
- Block user
- Comment

### Bulk tools
- Reaction
- Poll
- Join
- Leave
- Block
- Send private message
- Comment

### Monitor / reporting
- Keyword monitoring
- Ignore users
- Group discovery
- Report-status tools when configured

## Configuration

Copy `.env.example` to `.env` when installing on a new machine.

The existing `.env` supplied with this build is retained so the project can
start with the provided credentials. Keep the `.env` file private.

Required:
- `API_ID`
- `API_HASH`
- `BOT_TOKEN`
- `ADMIN_ID`

Optional:
- `CHANNEL_ID`
- `REPORT_CHECK_BOT`

## Run

```powershell
python -m pip install -r requirements.txt
python main.py
```

The working directory must be the project directory.

## Session layout

```text
sessions/
  session_*.session
```

Do not rename or move the supplied Session files unless you also update the
corresponding configuration.

## Safety of session deletion

There is intentionally no normal UI action that deletes a Session file.
The old project's destructive delete path was replaced with a preserved
archive/disable operation.

## Validation performed on this build

- Python syntax compilation across the project
- Callback-data length audit
- Keyboard callback routing audit
- Session path traversal review
- Session-file deletion search
- Existing Session discovery/migration logic review
- Account enable/disable lifecycle review
- Conversation/navigation review
- Legacy test updated for preservation semantics

A live Telegram test still requires the target machine to have network access
to Telegram and the required Python dependencies installed.
