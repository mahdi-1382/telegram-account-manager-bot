# Release 8.1.0

## Message Center
- Individual Reaction and Send PV are replaced by Message Center and Contacts.
- Choose one account or All Accounts.
- View conversations/channels.
- View the latest three messages without automatically marking the conversation as read.
- Filter to unread conversations.
- Retrieve contacts from one or all active accounts.

## Bulk Activity
- Bulk operations no longer ask for a numeric account count.
- Select accounts individually with toggle buttons.
- `All Accounts` remains available.
- The selected session names are preserved and used by the operation, so selecting accounts 2, 5, and 8 does not silently run accounts 1, 2, and 3.

## Existing functionality
- Existing sessions are preserved.
- No session file is deleted by this release.
- Existing Telegram account management, groups/channels, monitoring, comments, joins/leaves, polls and other operations remain in the project.

## Validation
- Python AST parsing passed for all Python files.
- `compileall` passed.
- Full pytest execution could not run in the build environment because Telethon was not installed there.
